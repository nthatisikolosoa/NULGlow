import { Router } from 'express'
import type { Config } from '../config.js'
import type { Db } from '../db.js'
import { parse } from '../errors.js'
import { reviewSchema } from '../schemas.js'

interface ReviewRow {
  id: number
  name: string
  course: string
  quote: string
  rating: number
  created_at: string
}
const toJson = (r: ReviewRow) => ({ id: r.id, name: r.name, course: r.course, quote: r.quote, rating: r.rating, createdAt: r.created_at })

export function reviewsRouter(db: Db, config: Config) {
  const r = Router()

  /** Newest student reviews first (by id, which is monotonic), then the starter reviews in their original order. */
  r.get('/', (_req, res) => {
    const rows = db
      .prepare(`SELECT id, name, course, quote, rating, created_at FROM reviews WHERE status = 'approved' ORDER BY (source = 'seed') ASC, CASE source WHEN 'user' THEN -id ELSE id END ASC`)
      .all() as ReviewRow[]
    const average = rows.length ? Math.round((rows.reduce((s, x) => s + x.rating, 0) / rows.length) * 10) / 10 : null
    res.json({ count: rows.length, average, reviews: rows.map(toJson) })
  })

  r.post('/', (req, res) => {
    const body = parse(reviewSchema, req.body)
    if (body.website) {
      res.status(201).json({ ok: true, published: true }) // bot: pretend it worked, store nothing
      return
    }
    const status = config.reviewsAutoApprove ? 'approved' : 'pending'
    const info = db.prepare(`INSERT INTO reviews (name, course, quote, rating, source, status) VALUES (?, ?, ?, ?, 'user', ?)`).run(body.name, body.course, body.quote, body.rating, status)
    const row = db.prepare(`SELECT id, name, course, quote, rating, created_at FROM reviews WHERE id = ?`).get(info.lastInsertRowid) as ReviewRow
    res.status(201).json({ ok: true, published: status === 'approved', review: toJson(row) })
  })

  return r
}

import { Router } from 'express'
import { z } from 'zod'
import type { Db } from '../db.js'
import { HttpError, parse } from '../errors.js'

const page = z.object({
  limit: z.coerce.number().int().min(1).max(500).default(100),
  offset: z.coerce.number().int().min(0).default(0),
  format: z.enum(['json', 'csv']).default('json'),
})
const idParam = z.object({ id: z.coerce.number().int().positive() })

const csvCell = (v: unknown) => {
  let s = v === null || v === undefined ? '' : String(v)
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}` // neutralise spreadsheet formula injection
  return `"${s.replace(/"/g, '""')}"`
}
const toCsv = (rows: Record<string, unknown>[]) => {
  if (!rows.length) return ''
  const cols = Object.keys(rows[0]!)
  return [cols.join(','), ...rows.map((r) => cols.map((c) => csvCell(r[c])).join(','))].join('\n') + '\n'
}

export function adminRouter(db: Db) {
  const r = Router()

  /** Generic list endpoint with pagination and optional CSV export (handy for newsletter tools). */
  const list = (path: string, table: string, where = '', cols = '*') =>
    r.get(path, (req, res) => {
      const q = parse(page, req.query)
      const rows = db.prepare(`SELECT ${cols} FROM ${table} ${where} ORDER BY id DESC LIMIT ? OFFSET ?`).all(q.limit, q.offset) as Record<string, unknown>[]
      const { total } = db.prepare(`SELECT COUNT(*) AS total FROM ${table} ${where}`).get() as { total: number }
      if (q.format === 'csv') return void res.type('text/csv').set('Content-Disposition', `attachment; filename="${table}.csv"`).send(toCsv(rows))
      res.json({ total, limit: q.limit, offset: q.offset, items: rows })
    })

  r.get('/summary', (_req, res) => {
    const n = (sql: string) => (db.prepare(sql).get() as { n: number }).n
    res.json({
      contactMessages: { total: n(`SELECT COUNT(*) n FROM contact_messages`), unhandled: n(`SELECT COUNT(*) n FROM contact_messages WHERE handled = 0`) },
      subscribers: { confirmed: n(`SELECT COUNT(*) n FROM subscribers WHERE status = 'confirmed'`), pending: n(`SELECT COUNT(*) n FROM subscribers WHERE status = 'pending'`), unsubscribed: n(`SELECT COUNT(*) n FROM subscribers WHERE status = 'unsubscribed'`) },
      students: n(`SELECT COUNT(*) n FROM students`),
      reviews: { approved: n(`SELECT COUNT(*) n FROM reviews WHERE status = 'approved'`), pending: n(`SELECT COUNT(*) n FROM reviews WHERE status = 'pending'`) },
    })
  })

  list('/contacts', 'contact_messages')
  list('/subscribers', 'subscribers', '', 'id, email, status, source, created_at, confirmed_at') // never expose tokens
  list('/students', 'students')
  list('/reviews', 'reviews')

  r.patch('/contacts/:id', (req, res) => {
    const { id } = parse(idParam, req.params)
    const { handled } = parse(z.object({ handled: z.boolean() }), req.body)
    const info = db.prepare(`UPDATE contact_messages SET handled = ? WHERE id = ?`).run(handled ? 1 : 0, id)
    if (!info.changes) throw new HttpError(404, 'Not found')
    res.json({ ok: true })
  })

  r.patch('/reviews/:id', (req, res) => {
    const { id } = parse(idParam, req.params)
    const { status } = parse(z.object({ status: z.enum(['pending', 'approved', 'rejected']) }), req.body)
    const info = db.prepare(`UPDATE reviews SET status = ? WHERE id = ?`).run(status, id)
    if (!info.changes) throw new HttpError(404, 'Not found')
    res.json({ ok: true })
  })

  r.delete('/reviews/:id', (req, res) => {
    const { id } = parse(idParam, req.params)
    const info = db.prepare(`DELETE FROM reviews WHERE id = ?`).run(id)
    if (!info.changes) throw new HttpError(404, 'Not found')
    res.status(204).end()
  })

  return r
}

import { randomBytes } from 'node:crypto'
import { Router } from 'express'
import type { Config } from '../config.js'
import type { Db } from '../db.js'
import { parse } from '../errors.js'
import { sendSafely, type Mailer } from '../services/mailer.js'
import { contactSchema, newsletterSchema, signupSchema, tokenQuery } from '../schemas.js'

const token = () => randomBytes(24).toString('hex') // 48 hex chars

interface SubRow {
  id: number
  email: string
  status: 'pending' | 'confirmed' | 'unsubscribed'
  confirm_token: string
  unsub_token: string
}

const page = (title: string, body: string, siteUrl: string) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} | NULGlow</title>
<style>body{font-family:system-ui,sans-serif;background:#fdf2f6;color:#3b1d33;display:grid;place-items:center;min-height:100vh;margin:0;padding:1rem}main{max-width:28rem;background:#fff;padding:2.5rem;border-radius:1.5rem;text-align:center;box-shadow:0 12px 40px rgba(157,78,124,.18)}a{color:#9d4e7c;font-weight:600}</style></head>
<body><main><h1>${title}</h1><p>${body}</p><p><a href="${siteUrl}">Back to NULGlow</a></p></main></body></html>`

export function formsRouter(db: Db, config: Config, mailer: Mailer) {
  const r = Router()

  /** Create a pending subscriber (or re-send the confirmation to an existing pending one). Returns the row, or null if already confirmed. */
  function startSubscription(emailAddr: string, source: string): SubRow | null {
    const existing = db.prepare(`SELECT * FROM subscribers WHERE email = ?`).get(emailAddr) as SubRow | undefined
    if (!existing) {
      const row = { confirm_token: token(), unsub_token: token() }
      db.prepare(`INSERT INTO subscribers (email, status, confirm_token, unsub_token, source) VALUES (?, 'pending', ?, ?, ?)`).run(emailAddr, row.confirm_token, row.unsub_token, source)
      return db.prepare(`SELECT * FROM subscribers WHERE email = ?`).get(emailAddr) as SubRow
    }
    if (existing.status === 'confirmed') return null
    // pending or previously unsubscribed: ask them to (re)confirm
    db.prepare(`UPDATE subscribers SET status = 'pending', confirmed_at = NULL WHERE id = ?`).run(existing.id)
    return { ...existing, status: 'pending' }
  }

  const confirmLink = (t: string) => `${config.publicApiUrl}/api/newsletter/confirm?token=${t}`
  const unsubLink = (t: string) => `${config.publicApiUrl}/api/newsletter/unsubscribe?token=${t}`

  // ---- Contact form ----
  r.post('/contact', (req, res) => {
    const b = parse(contactSchema, req.body)
    if (b.website) {
      res.status(201).json({ ok: true })
      return
    }
    db.prepare(`INSERT INTO contact_messages (name, email, topic, message) VALUES (?, ?, ?, ?)`).run(b.name, b.email, b.topic, b.message)
    sendSafely(mailer, {
      to: config.contactInbox,
      replyTo: b.email,
      subject: `[NULGlow] ${b.topic}: message from ${b.name}`,
      text: `From: ${b.name} <${b.email}>\nTopic: ${b.topic}\n\n${b.message}\n`,
    })
    res.status(201).json({ ok: true, message: `Thanks, ${b.name.split(' ')[0]}. Message sent. We reply within two working days.` })
  })

  // ---- Newsletter: double opt-in ----
  r.post('/newsletter/subscribe', (req, res) => {
    const b = parse(newsletterSchema, req.body)
    // Same response whether or not the address is new, so the endpoint can't be used to probe who is subscribed.
    const done = () => res.status(202).json({ ok: true, message: "You're in. Check your inbox to confirm." })
    if (b.website) return void done()
    const sub = startSubscription(b.email, 'footer')
    if (sub) {
      sendSafely(mailer, {
        to: sub.email,
        subject: 'Confirm your NULGlow weekly drop',
        text: `Hi!\n\nTap the link to confirm your subscription to the NULGlow weekly drop (student deals + one pharmacist tip, every Friday):\n\n${confirmLink(sub.confirm_token)}\n\nIf you didn't ask for this, just ignore this email.\n`,
      })
    }
    done()
  })

  r.get('/newsletter/confirm', (req, res) => {
    const { token: t } = parse(tokenQuery, req.query)
    const row = db.prepare(`SELECT * FROM subscribers WHERE confirm_token = ?`).get(t) as SubRow | undefined
    if (!row) return void res.status(404).type('html').send(page('Link not found', 'This confirmation link is invalid or has expired.', config.siteUrl))
    db.prepare(`UPDATE subscribers SET status = 'confirmed', confirmed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`).run(row.id)
    res.type('html').send(page("You're subscribed", 'Thanks for confirming. Look out for the weekly drop every Friday.', config.siteUrl))
  })

  r.get('/newsletter/unsubscribe', (req, res) => {
    const { token: t } = parse(tokenQuery, req.query)
    const row = db.prepare(`SELECT * FROM subscribers WHERE unsub_token = ?`).get(t) as SubRow | undefined
    if (!row) return void res.status(404).type('html').send(page('Link not found', 'This unsubscribe link is invalid.', config.siteUrl))
    db.prepare(`UPDATE subscribers SET status = 'unsubscribed' WHERE id = ?`).run(row.id)
    res.type('html').send(page('Unsubscribed', "You won't get the weekly drop any more. You can re-subscribe any time from the site footer.", config.siteUrl))
  })

  // ---- Student sign-up dialog ----
  r.post('/signup', (req, res) => {
    const b = parse(signupSchema, req.body)
    const ok = () => res.status(201).json({ ok: true, message: `Welcome, ${b.name.split(' ')[0]}. We'll send student deals and routine tips to ${b.email}.` })
    if (b.website) return void ok()

    // Upsert: signing up twice with the same email updates the profile instead of erroring.
    db.prepare(
      `INSERT INTO students (name, email, skin_type, concerns) VALUES (?, ?, ?, ?)
       ON CONFLICT(email) DO UPDATE SET name = excluded.name,
         skin_type = COALESCE(excluded.skin_type, students.skin_type),
         concerns = COALESCE(excluded.concerns, students.concerns),
         updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')`,
    ).run(b.name, b.email, b.skinType ?? null, b.concerns ?? null)

    // Sign-up also opts them in to the weekly drop; one welcome email carries the confirmation link.
    const sub = startSubscription(b.email, 'signup')
    sendSafely(mailer, {
      to: b.email,
      subject: 'Welcome to NULGlow',
      text:
        `Hi ${b.name.split(' ')[0]},\n\nWelcome to NULGlow! Build your routine any time at ${config.siteUrl}/#/recommendations\n\n` +
        (sub ? `To get the weekly deals email, confirm here:\n${confirmLink(sub.confirm_token)}\n\n` : '') +
        `Free skin consults run every Wednesday, 12:00-16:00, at Mzalas Complex Pharmacy. No booking needed.\n`,
    })
    ok()
  })

  return r
}

import { Router, type Response } from 'express'
import { z } from 'zod'
import { BRANDS, CONCERNS, DEALS, PLANS, STATS } from '../data/catalog.js'
import { BUDGETS, SKIN_TYPES } from '../data/constants.js'
import { parse } from '../errors.js'
import { PRODUCTS, brandsWithStats, buildRoutine, concernsResolved } from '../services/catalog.js'

const STEPS = ['Cleanse', 'Tone', 'Treat', 'Moisturize', 'Protect'] as const
const BRAND_NAMES = BRANDS.map((b) => b.name) as [string, ...string[]]
const CONCERN_LABELS = CONCERNS.map((c) => c.label)

/** Catalog content changes rarely: let browsers/CDNs cache it briefly. */
const cache = (res: Response) => res.set('Cache-Control', 'public, max-age=300')

const productQuery = z.object({
  step: z.enum(STEPS).optional(),
  brand: z.enum(BRAND_NAMES).optional(),
  q: z.string().trim().max(80).optional(),
  minPrice: z.coerce.number().min(0).optional(),
  maxPrice: z.coerce.number().min(0).optional(),
  sort: z.enum(['price_asc', 'price_desc', 'name']).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
})

const routineQuery = z.object({
  skin: z.enum(SKIN_TYPES as [string, ...string[]], { message: `skin must be one of: ${SKIN_TYPES.join(', ')}` }),
  budget: z.enum(BUDGETS as [string, ...string[]], { message: `budget must be one of: ${BUDGETS.join(', ')}` }),
  // comma-separated concern labels, e.g. concerns=Acne and breakouts,Vitiligo
  concerns: z
    .string()
    .optional()
    .transform((v) => (v ? v.split(',').map((s) => s.trim()).filter(Boolean) : []))
    .refine((arr) => arr.every((l) => CONCERN_LABELS.includes(l)), { message: `Unknown concern. Valid: ${CONCERN_LABELS.join(', ')}` }),
})

export function catalogRouter() {
  const r = Router()

  r.get('/stats', (_req, res) => {
    cache(res).json({ stats: STATS })
  })

  r.get('/products', (req, res) => {
    const q = parse(productQuery, req.query)
    let items = PRODUCTS.filter(
      (p) =>
        (!q.step || p.step === q.step) &&
        (!q.brand || p.brand === q.brand) &&
        (q.minPrice === undefined || p.price >= q.minPrice) &&
        (q.maxPrice === undefined || p.price <= q.maxPrice) &&
        (!q.q || `${p.name} ${p.tip} ${p.brand}`.toLowerCase().includes(q.q.toLowerCase())),
    )
    if (q.sort === 'price_asc') items = [...items].sort((a, b) => a.price - b.price)
    else if (q.sort === 'price_desc') items = [...items].sort((a, b) => b.price - a.price)
    else if (q.sort === 'name') items = [...items].sort((a, b) => a.name.localeCompare(b.name))
    const total = items.length
    cache(res).json({ total, products: q.limit ? items.slice(0, q.limit) : items, steps: STEPS, brands: BRAND_NAMES })
  })

  r.get('/brands', (_req, res) => {
    cache(res).json({ brands: brandsWithStats() })
  })

  r.get('/concerns', (_req, res) => {
    cache(res).json({ concerns: concernsResolved() })
  })

  r.get('/routines/options', (_req, res) => {
    cache(res).json({ skinTypes: SKIN_TYPES, budgets: BUDGETS, concerns: CONCERN_LABELS })
  })

  /** Equivalent of the frontend RoutineBuilder: skin + budget (+ optional concerns) -> steps, total, concern advice. */
  r.get('/routines', (req, res) => {
    const q = parse(routineQuery, req.query)
    const routine = buildRoutine(q.skin as never, q.budget as never)
    cache(res).json({ ...routine, concerns: q.concerns.length ? concernsResolved(q.concerns) : [] })
  })

  r.get('/deals', (req, res) => {
    const { store, limit } = parse(z.object({ store: z.string().trim().max(80).optional(), limit: z.coerce.number().int().min(1).max(50).optional() }), req.query)
    let deals = DEALS.map((d) => ({ ...d }))
    if (store) deals = deals.filter((d) => d.store.toLowerCase() === store.toLowerCase())
    cache(res).json({ deals: limit ? deals.slice(0, limit) : deals })
  })

  r.get('/plans', (_req, res) => {
    cache(res).json({ currency: 'M', period: 'month', plans: PLANS })
  })

  return r
}

import { BRANDS, CONCERNS, ROUTINES, SHELF, type Budget, type Concern, type ShelfBrand, type ShelfProduct, type SkinType } from '../data/catalog.js'

const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')

export type CatalogProduct = ShelfProduct & { id: string }

/** Shelf products with a stable, URL-safe id (brand + name). */
export const PRODUCTS: CatalogProduct[] = SHELF.map((p) => ({ id: slug(`${p.brand}-${p.name}`), ...p }))

const byName = new Map(PRODUCTS.map((p) => [p.name, p]))

export function brandsWithStats() {
  return BRANDS.map((b) => {
    const prices = PRODUCTS.filter((p) => p.brand === b.name).map((p) => p.price)
    return {
      ...b,
      id: slug(b.name),
      productCount: prices.length,
      priceRange: prices.length ? { min: Math.round(Math.min(...prices)), max: Math.round(Math.max(...prices)) } : null,
    }
  })
}

export function concernsResolved(labels?: string[]) {
  const list: Concern[] = labels ? CONCERNS.filter((c) => labels.includes(c.label)) : CONCERNS
  return list.map((c) => ({
    label: c.label,
    advice: c.advice,
    seeDoctor: !!c.doctor,
    picks: c.picks.map((n) => byName.get(n)).filter((p): p is CatalogProduct => !!p),
  }))
}

export function buildRoutine(skin: SkinType, budget: Budget) {
  const steps = ROUTINES[skin][budget]
  const total = steps.reduce((sum, s) => sum + s.product.price, 0)
  return { skin, budget, steps, total, productCount: steps.length }
}

export type { ShelfBrand }
export { slug }

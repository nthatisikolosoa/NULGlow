import nodemailer from 'nodemailer'
import type { Config } from '../config.js'

export interface Mail {
  to: string
  subject: string
  text: string
  replyTo?: string
}
export interface Mailer {
  send(mail: Mail): Promise<void>
}

/** Strip CR/LF so user-supplied text can never inject extra email headers. */
const oneLine = (s: string) => s.replace(/[\r\n]+/g, ' ').trim()

/**
 * Real SMTP when SMTP_HOST is configured; otherwise emails are printed to the console
 * so the whole flow (including confirm links) is testable locally with zero setup.
 */
export function createMailer(config: Config): Mailer {
  const { smtp, mailFrom } = config
  if (!smtp.host) {
    return {
      async send(m) {
        console.log(`\n[mail:dev] To: ${m.to}\n[mail:dev] Subject: ${oneLine(m.subject)}\n${m.text}\n`)
      },
    }
  }
  const transport = nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    secure: smtp.secure,
    auth: smtp.user ? { user: smtp.user, pass: smtp.pass } : undefined,
  })
  return {
    async send(m) {
      await transport.sendMail({ from: mailFrom, to: m.to, subject: oneLine(m.subject), text: m.text, replyTo: m.replyTo })
    },
  }
}

/** Send without ever failing the request: the data is already saved, a mail hiccup must not lose it. */
export function sendSafely(mailer: Mailer, mail: Mail) {
  mailer.send(mail).catch((err) => console.error('[mail] failed to send:', (err as Error).message))
}

import { timingSafeEqual } from 'node:crypto'
import type { RequestHandler } from 'express'
import { rateLimit } from 'express-rate-limit'
import { HttpError } from './errors.js'

/** Bearer-token guard for /api/admin/*. If ADMIN_TOKEN isn't configured the admin API is disabled entirely. */
export function requireAdmin(adminToken: string): RequestHandler {
  const expected = Buffer.from(adminToken)
  return (req, _res, next) => {
    if (!adminToken) return next(new HttpError(503, 'Admin API is disabled. Set ADMIN_TOKEN to enable it.'))
    const given = Buffer.from((req.get('authorization') ?? '').replace(/^Bearer\s+/i, ''))
    const ok = given.length === expected.length && timingSafeEqual(given, expected)
    if (!ok) return next(new HttpError(401, 'Unauthorized'))
    next()
  }
}

const limiter = (windowMs: number, limit: number, message: string) =>
  rateLimit({ windowMs, limit, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: message } })

export const apiLimiter = limiter(60_000, 240, 'Too many requests. Please slow down.')
/** Form submissions are the abuse target (spam, email bombing): keep them tight. */
export const formLimiter = limiter(15 * 60_000, 15, 'Too many submissions. Please try again in a few minutes.')

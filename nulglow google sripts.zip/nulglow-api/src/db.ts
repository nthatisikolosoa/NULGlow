import Database from 'better-sqlite3'
import { mkdirSync } from 'node:fs'
import { dirname } from 'node:path'
import { REVIEWS } from './data/catalog.js'

export type Db = Database.Database

const SCHEMA = `
CREATE TABLE IF NOT EXISTS reviews (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  course     TEXT NOT NULL,
  quote      TEXT NOT NULL,
  rating     INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  source     TEXT NOT NULL DEFAULT 'user' CHECK (source IN ('seed','user')),
  status     TEXT NOT NULL DEFAULT 'approved' CHECK (status IN ('pending','approved','rejected')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_reviews_status ON reviews(status, source, created_at);

CREATE TABLE IF NOT EXISTS contact_messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL,
  topic      TEXT NOT NULL,
  message    TEXT NOT NULL,
  handled    INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS subscribers (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','unsubscribed')),
  confirm_token TEXT NOT NULL UNIQUE,
  unsub_token   TEXT NOT NULL UNIQUE,
  source        TEXT NOT NULL DEFAULT 'footer',
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  confirmed_at  TEXT
);

CREATE TABLE IF NOT EXISTS students (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL UNIQUE,
  skin_type  TEXT,
  concerns   TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
`

/** Open (and create if needed) the SQLite database, apply the schema and seed the starter reviews. */
export function openDb(path: string): Db {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true })
  const db = new Database(path)
  db.pragma('journal_mode = WAL')
  db.pragma('foreign_keys = ON')
  db.exec(SCHEMA)
  seedReviews(db)
  return db
}

/** The four starter reviews from the frontend are stored once so they can be moderated like any other. */
function seedReviews(db: Db) {
  const { n } = db.prepare(`SELECT COUNT(*) AS n FROM reviews WHERE source = 'seed'`).get() as { n: number }
  if (n > 0) return
  const insert = db.prepare(`INSERT INTO reviews (name, course, quote, rating, source, status) VALUES (?, ?, ?, ?, 'seed', 'approved')`)
  db.transaction(() => {
    for (const r of REVIEWS) insert.run(r.name, r.course, r.quote, r.rating)
  })()
}

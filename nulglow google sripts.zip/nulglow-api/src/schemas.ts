import { z } from 'zod'
import { SKIN_TYPES } from './data/constants.js'

/** Same rule and wording as the frontend so inline errors read identically. */
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const stripControl = (s: string) => s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')

export const text = (min: number, max: number, minMsg: string) =>
  z
    .string({ message: minMsg })
    .transform((s) => stripControl(s).trim())
    .pipe(z.string().min(min, minMsg).max(max, `Keep this under ${max} characters.`))

/** For one-line fields (names etc.): line breaks and tabs collapse to a single space. */
export const line = (min: number, max: number, minMsg: string) =>
  z
    .string({ message: minMsg })
    .transform((s) => stripControl(s).replace(/\s+/g, ' ').trim())
    .pipe(z.string().min(min, minMsg).max(max, `Keep this under ${max} characters.`))

export const email = z
  .string({ message: 'Enter a valid email address.' })
  .transform((s) => s.trim().toLowerCase())
  .pipe(z.string().max(254, 'Enter a valid email address.').regex(EMAIL, 'Enter a valid email address.'))

/** Hidden "website" field that real people never fill in; bots do. */
export const honeypot = z.string().max(500).optional()

export const TOPICS = ['Routine help', 'Store partnership', 'Hall plan', 'Something else'] as const

export const contactSchema = z.object({
  name: line(2, 80, 'Enter your name (2+ characters).'),
  email,
  topic: z.enum(TOPICS).default('Routine help'),
  message: text(10, 2000, 'Tell us a little more (10+ characters).'),
  website: honeypot,
})

export const reviewSchema = z.object({
  name: line(1, 80, 'Please add your name.'),
  course: z
    .string()
    .optional()
    .transform((s) => stripControl(s ?? '').replace(/\s+/g, ' ').trim().slice(0, 80) || 'NUL student'),
  quote: text(15, 300, 'Tell us a little more (at least 15 characters).'),
  rating: z.coerce.number().int().min(1, 'Choose a rating from 1 to 5.').max(5, 'Choose a rating from 1 to 5.').default(5),
  website: honeypot,
})

export const newsletterSchema = z.object({ email, website: honeypot })

export const signupSchema = z.object({
  name: line(1, 80, 'Please enter your name.'),
  email,
  skinType: z
    .string()
    .optional()
    .transform((s) => s?.trim() || undefined)
    .refine((s) => s === undefined || (SKIN_TYPES as readonly string[]).includes(s), { message: `Skin type must be one of: ${SKIN_TYPES.join(', ')}.` }),
  concerns: z
    .string()
    .optional()
    .transform((s) => stripControl(s ?? '').replace(/\s+/g, ' ').trim().slice(0, 200) || undefined),
  website: honeypot,
})

export const tokenQuery = z.object({ token: z.string().regex(/^[a-f0-9]{48}$/, 'Invalid link.') })

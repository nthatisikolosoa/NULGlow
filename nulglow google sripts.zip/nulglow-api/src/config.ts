import 'dotenv/config'
import { existsSync } from 'node:fs'

const bool = (v: string | undefined, d: boolean) => (v === undefined || v === '' ? d : !['false', '0', 'no'].includes(v.toLowerCase()))
const int = (v: string | undefined, d: number) => {
  const n = Number(v)
  return Number.isFinite(n) && v !== undefined && v !== '' ? n : d
}

export const config = {
  env: process.env.NODE_ENV ?? 'development',
  port: int(process.env.PORT, 3001),
  databasePath: process.env.DATABASE_PATH ?? './data/nulglow.db',
  corsOrigins: (process.env.CORS_ORIGINS ?? 'http://localhost:5173').split(',').map((s) => s.trim()).filter(Boolean),
  trustProxy: int(process.env.TRUST_PROXY, 0),
  publicApiUrl: (process.env.PUBLIC_API_URL ?? `http://localhost:${int(process.env.PORT, 3001)}`).replace(/\/$/, ''),
  siteUrl: (process.env.SITE_URL ?? 'http://localhost:5173').replace(/\/$/, ''),
  // Serve the built website from this same server. Defaults to ./web/dist when it exists (run `npm run build` first).
  frontendDist: process.env.FRONTEND_DIST || (existsSync('web/dist') ? 'web/dist' : undefined),
  adminToken: process.env.ADMIN_TOKEN ?? '',
  reviewsAutoApprove: bool(process.env.REVIEWS_AUTO_APPROVE, true),
  contactInbox: process.env.CONTACT_INBOX ?? 'clara.kolosoan@gmail.com',
  mailFrom: process.env.MAIL_FROM ?? 'NULGlow <no-reply@nulglow.example>',
  smtp: {
    host: process.env.SMTP_HOST || undefined,
    port: int(process.env.SMTP_PORT, 587),
    secure: bool(process.env.SMTP_SECURE, false),
    user: process.env.SMTP_USER || undefined,
    pass: process.env.SMTP_PASS || undefined,
  },
}

export type Config = typeof config

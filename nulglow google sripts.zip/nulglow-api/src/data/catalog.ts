/** Static content for NULGlow. Prices are in USD; stores are local to campus. */

export type SkinType = 'Oily' | 'Dry' | 'Combination' | 'Sensitive'
export type Budget = 'Under M300' | 'Under M550' | 'Under M900'

export interface Product {
  name: string
  store: string
  price: number
  note: string
}
export interface Step {
  step: string
  product: Product
}

/** Source prices are modelled in USD and converted to Maloti (M), rounded to the nearest M5. */
const P = (name: string, store: string, usd: number, note: string): Product => ({ name, store, price: Math.round((usd * 18) / 5) * 5, note })

/** Routine matrix: skin type -> budget tier -> ordered steps. */
export const ROUTINES: Record<SkinType, Record<Budget, Step[]>> = {
  Oily: {
    'Under M300': [
      { step: 'Cleanse', product: P('Salicylic Foaming Wash', 'Dollar Beauty Mart', 3.5, 'Clears pores without stripping.') },
      { step: 'Moisturize', product: P('Oil-Free Gel Cream', 'Campus Pharmacy', 4.99, 'Light hydration, zero shine.') },
      { step: 'Protect', product: P('Matte Gel SPF 50', 'Dollar Beauty Mart', 6.0, 'Sits well under makeup.') },
    ],
    'Under M550': [
      { step: 'Cleanse', product: P('Gentle Gel Cleanser', 'Campus Pharmacy', 8.5, 'pH-balanced daily wash.') },
      { step: 'Treat', product: P('2% Niacinamide Serum', 'Glow & Co. Corner Shop', 7.9, 'Refines pores and oil.') },
      { step: 'Moisturize', product: P('Oil-Free Gel Cream', 'Campus Pharmacy', 4.99, 'Light hydration, zero shine.') },
      { step: 'Protect', product: P('Matte Gel SPF 50', 'Dollar Beauty Mart', 6.0, 'Sits well under makeup.') },
    ],
    'Under M900': [
      { step: 'Cleanse', product: P('Gentle Gel Cleanser', 'Campus Pharmacy', 8.5, 'pH-balanced daily wash.') },
      { step: 'Treat', product: P('2% BHA Liquid Exfoliant', 'Glow & Co. Corner Shop', 14.0, 'Use three nights a week.') },
      { step: 'Treat', product: P('10% Niacinamide Serum', 'Glow & Co. Corner Shop', 9.5, 'Oil control, brighter tone.') },
      { step: 'Moisturize', product: P('Barrier Gel Cream', 'Campus Pharmacy', 9.0, 'Ceramides, no grease.') },
      { step: 'Protect', product: P('Fluid SPF 50 PA++++', 'Glow & Co. Corner Shop', 8.0, 'Invisible finish.') },
    ],
  },
  Dry: {
    'Under M300': [
      { step: 'Cleanse', product: P('Creamy Milk Cleanser', 'Campus Pharmacy', 4.5, 'Cleans without tightness.') },
      { step: 'Moisturize', product: P('Glycerin Barrier Cream', 'Dollar Beauty Mart', 5.5, 'Rich, fragrance-free.') },
      { step: 'Protect', product: P('Hydrating SPF 30', 'Dollar Beauty Mart', 4.5, 'Dewy daytime finish.') },
    ],
    'Under M550': [
      { step: 'Cleanse', product: P('Creamy Milk Cleanser', 'Campus Pharmacy', 4.5, 'Cleans without tightness.') },
      { step: 'Treat', product: P('Hyaluronic Acid Serum', 'Glow & Co. Corner Shop', 8.0, 'Apply on damp skin.') },
      { step: 'Moisturize', product: P('Ceramide Night Cream', 'Campus Pharmacy', 9.9, 'Repairs overnight.') },
      { step: 'Protect', product: P('Hydrating SPF 50', 'Glow & Co. Corner Shop', 7.0, 'Dewy daytime finish.') },
    ],
    'Under M900': [
      { step: 'Cleanse', product: P('Cream-to-Oil Cleanser', 'Glow & Co. Corner Shop', 10.0, 'Melts sunscreen away.') },
      { step: 'Treat', product: P('Hyaluronic + B5 Serum', 'Glow & Co. Corner Shop', 10.5, 'Plumps in two weeks.') },
      { step: 'Moisturize', product: P('Ceramide Barrier Cream', 'Campus Pharmacy', 12.0, 'Seals in moisture.') },
      { step: 'Protect', product: P('Hydrating SPF 50', 'Glow & Co. Corner Shop', 7.0, 'Dewy daytime finish.') },
    ],
  },
  Combination: {
    'Under M300': [
      { step: 'Cleanse', product: P('Gentle Gel Cleanser', 'Campus Pharmacy', 5.5, 'Balanced for both zones.') },
      { step: 'Moisturize', product: P('Lightweight Lotion', 'Dollar Beauty Mart', 4.5, 'Hydrates, never heavy.') },
      { step: 'Protect', product: P('Daily Fluid SPF 50', 'Dollar Beauty Mart', 5.0, 'Weightless.') },
    ],
    'Under M550': [
      { step: 'Cleanse', product: P('Gentle Gel Cleanser', 'Campus Pharmacy', 5.5, 'Balanced for both zones.') },
      { step: 'Treat', product: P('5% Niacinamide Serum', 'Glow & Co. Corner Shop', 7.0, 'Evens oil and tone.') },
      { step: 'Moisturize', product: P('Lightweight Lotion', 'Dollar Beauty Mart', 4.5, 'Hydrates, never heavy.') },
      { step: 'Protect', product: P('Daily Fluid SPF 50', 'Dollar Beauty Mart', 5.0, 'Weightless.') },
    ],
    'Under M900': [
      { step: 'Cleanse', product: P('Low-pH Cleanser', 'Glow & Co. Corner Shop', 9.0, 'Gentle, effective.') },
      { step: 'Treat', product: P('Azelaic Acid 10%', 'Campus Pharmacy', 11.0, 'Calms redness and texture.') },
      { step: 'Moisturize', product: P('Gel-Cream Hydrator', 'Campus Pharmacy', 9.0, 'Zone-friendly.') },
      { step: 'Protect', product: P('Daily Fluid SPF 50', 'Dollar Beauty Mart', 5.0, 'Weightless.') },
    ],
  },
  Sensitive: {
    'Under M300': [
      { step: 'Cleanse', product: P('Fragrance-Free Cream Wash', 'Campus Pharmacy', 5.0, 'Dermatologist tested.') },
      { step: 'Moisturize', product: P('Colloidal Oat Cream', 'Campus Pharmacy', 6.0, 'Soothes irritation.') },
      { step: 'Protect', product: P('Mineral SPF 30', 'Dollar Beauty Mart', 4.0, 'Zinc oxide only.') },
    ],
    'Under M550': [
      { step: 'Cleanse', product: P('Fragrance-Free Cream Wash', 'Campus Pharmacy', 5.0, 'Dermatologist tested.') },
      { step: 'Treat', product: P('Centella Calming Serum', 'Glow & Co. Corner Shop', 9.0, 'Redness relief.') },
      { step: 'Moisturize', product: P('Colloidal Oat Cream', 'Campus Pharmacy', 6.0, 'Soothes irritation.') },
      { step: 'Protect', product: P('Mineral SPF 50', 'Glow & Co. Corner Shop', 8.0, 'Zinc oxide only.') },
    ],
    'Under M900': [
      { step: 'Cleanse', product: P('Micellar Cream Cleanser', 'Glow & Co. Corner Shop', 9.0, 'No rinsing sting.') },
      { step: 'Treat', product: P('Centella + Panthenol Serum', 'Glow & Co. Corner Shop', 12.0, 'Rebuilds barrier.') },
      { step: 'Moisturize', product: P('Barrier Repair Cream', 'Campus Pharmacy', 11.0, 'Ceramides + oat.') },
      { step: 'Protect', product: P('Mineral SPF 50', 'Glow & Co. Corner Shop', 8.0, 'Zinc oxide only.') },
    ],
  },
}

export const DEALS = [
  { store: 'Dollar Beauty Mart', off: '30%', title: 'Student Skincare Shelf', detail: 'Cleansers, SPF and moisturizers. Show your student ID at checkout.', code: 'NULGLOW30', until: 'Ends 31 Oct', img: 'nul-deal-1' },
  { store: 'Campus Pharmacy', off: '2 for 1', title: 'Ceramide Creams', detail: 'Buy one barrier cream, get a second free. Share with your roommate.', code: 'TWOCREAM', until: 'Ends 15 Nov', img: 'nul-deal-2' },
  { store: 'Glow & Co. Corner Shop', off: 'M90 off', title: 'First Serum Order', detail: 'Any serum over M180. Includes niacinamide and centella.', code: 'FIRSTGLOW', until: 'Ends 30 Nov', img: 'nul-deal-3' },
  { store: 'Dollar Beauty Mart', off: '20%', title: 'Mineral Sunscreens', detail: 'Zinc SPF 30 and 50 in all sizes. Great for sensitive skin.', code: 'SUNSAFE20', until: 'Ends 20 Nov', img: 'nul-deal-4' },
  { store: 'Mzalas Complex Pharmacy', off: 'Free', title: 'Skin Check Consult', detail: 'Ten-minute chat with a pharmacist. Walk in, no booking needed.', code: 'WALKIN', until: 'Wednesdays, 12:00–16:00', img: 'nul-deal-5' },
  { store: 'Glow & Co. Corner Shop', off: '15%', title: 'Exfoliant Bundle', detail: 'BHA + moisturizer pairing, picked by our team.', code: 'BUNDLE15', until: 'Ends 10 Dec', img: 'nul-deal-6' },
]

export interface Review {
  name: string
  course: string
  quote: string
  rating: number
}
export const REVIEWS: Review[] = [
  { name: 'Amara O.', course: 'Biochemistry, Year 2', quote: 'I was spending M1,100 a month on products that did nothing. NULGlow got me a full routine for M400 and my breakouts calmed in three weeks.', rating: 5 },
  { name: 'Daniel K.', course: 'Engineering, Year 3', quote: 'No jargon. I picked oily, set my budget, and had a shopping list in under a minute. Walked to the corner shop and bought it all.', rating: 5 },
  { name: 'Priya S.', course: 'Law, Year 1', quote: 'My skin is sensitive and I was scared to try anything. The pharmacist notes explained exactly what to avoid. Zero irritation so far.', rating: 5 },
  { name: 'Mateo R.', course: 'Design, Year 4', quote: 'The discount page paid for itself on day one. Student deals I never knew existed, all in one place.', rating: 4 },
]

export const PLANS = [
  { name: 'Starter', price: 0, blurb: 'Everything you need to begin.', features: ['Routine builder', 'Public discount listings', 'Product ingredient notes'], cta: 'Start free', featured: false },
  { name: 'Glow', price: 75, blurb: 'For students serious about results.', features: ['Everything in Starter', 'Members-only store codes', 'Monthly pharmacist Q&A', 'Routine progress tracker', 'Ingredient conflict checker'], cta: 'Join Glow', featured: true },
  { name: 'Hall', price: 215, blurb: 'Share the savings with your hall.', features: ['Everything in Glow', 'Up to 6 members', 'Group bulk-buy alerts', 'Priority consult slots'], cta: 'Get Hall plan', featured: false },
]

export const STATS = [
  { value: 'M480', label: 'Average monthly saving' },
  { value: '4,800+', label: 'Student routines built' },
  { value: '3', label: 'Partner local stores' },
  { value: '92%', label: 'Report clearer skin in 8 weeks' },
]

/** Portia M range. Source prices are in rand; the loti is pegged 1:1 to the rand, so amounts are shown as Maloti. */
export type ShelfStep = 'Cleanse' | 'Tone' | 'Treat' | 'Moisturize' | 'Protect'
export type ShelfBrand = 'Portia M' | 'Garnier' | 'CeraVe'
export interface ShelfProduct {
  brand: ShelfBrand
  name: string
  price: number
  step: ShelfStep
  tip: string
  img: string
  url: string
}
const U = 'https://portiamss.com/wp-content/uploads/'
const S = 'https://portiamss.com/product/'
export const SHELF: ShelfProduct[] = [
  { brand: 'Portia M', name: 'Marula Face Wash 150ml', price: 65.25, step: 'Cleanse', tip: 'Everyday cleanse for most skin types.', img: `${U}2023/07/Face-Wash-300x300.png`, url: `${S}marula-face-wash-150ml/` },
  { brand: 'Portia M', name: 'Face Wash Sulphate Free 150ml', price: 65.25, step: 'Cleanse', tip: 'Gentler pick if your skin feels tight.', img: `${U}2023/07/Sulphate-Face-wash-300x300.png`, url: `${S}face-wash-sulphate-free-150ml/` },
  { brand: 'Portia M', name: 'Marula Micellar Water 200ml', price: 79.8, step: 'Cleanse', tip: 'Lifts makeup and sunscreen in one swipe.', img: `${U}2025/02/Marula-Micellar-Water-200ml-front-300x300.png`, url: `${S}marula-micellar-water200ml/` },
  { brand: 'Portia M', name: 'Marula Skin Toner 200ml', price: 63.87, step: 'Tone', tip: 'Resets skin after washing.', img: `${U}2023/10/Marula-Skin-Toner-200ml-front-300x300.png`, url: `${S}marula-skin-toner-200ml/` },
  { brand: 'Portia M', name: 'Pomegranate Toner 200ml', price: 84.72, step: 'Tone', tip: 'Light, refreshing, good for combination skin.', img: `${U}2023/10/Pomegranate-Toner-front-300x300.png`, url: `${S}pomegranate-toner/` },
  { brand: 'Portia M', name: 'VitaGlow Serum 50ml', price: 188.0, step: 'Treat', tip: 'Brightening serum for dull, tired skin.', img: `${U}2024/08/VitaGlow-Serum-50ml-back-300x300.png`, url: `${S}vitaglow-serum-50ml/` },
  { brand: 'Portia M', name: 'HyaluraGlow Serum 50ml', price: 198.45, step: 'Treat', tip: 'Hydration boost for dry or dehydrated skin.', img: `${U}2024/08/HyaluraGlow-Serum-50ml-front-300x300.png`, url: `${S}hyaluraglow-serum-50ml/` },
  { brand: 'Portia M', name: 'Rejuvenate + Serum 50ml', price: 194.27, step: 'Treat', tip: 'Smoothing serum for texture and fine lines.', img: `${U}2024/09/Rejuvanate-Serum-50ml-front-300x300.png`, url: `${S}rejuvenate-serum-50ml/` },
  { brand: 'Portia M', name: 'Marula Day Cream for Oily Skin 50ml', price: 81.03, step: 'Moisturize', tip: 'Light daytime hydration without the shine.', img: `${U}2023/10/Marula-Day-Cream-for-Oily-Skin-50ml-front-300x300.png`, url: `${S}marula-day-cream-50ml/` },
  { brand: 'Portia M', name: 'Marula Day Cream for Normal Skin 50ml', price: 82.25, step: 'Moisturize', tip: 'Everyday moisture for balanced skin.', img: `${U}2023/10/New-Boxes-6.png`, url: `${S}marula-skin-day-cream-50ml/` },
  { brand: 'Portia M', name: 'Marula Night Cream 50ml', price: 88.41, step: 'Moisturize', tip: 'Overnight repair while you sleep.', img: `${U}2023/10/New-Boxes-4.png`, url: `${S}marula-night-cream-50ml/` },
  { brand: 'Portia M', name: 'Marula Sunscreen Lotion', price: 146.04, step: 'Protect', tip: 'Daily SPF, the one step you should never skip.', img: `${U}2023/10/Marula-Oil-Sunscreen-lotion-front-300x300.png`, url: `${S}marula-sunscreen-lotion/` },
  { brand: 'Garnier', name: "Pure Active Ideal Complexion Daily Cream 40ml", price: 77.7, step: 'Moisturize', tip: "Hydrates breakout-prone skin without grease.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDIxOTM0fGltYWdlL2pwZWd8YURjMEwyZ3lPQzh4TVRrME5EazBOakl6TnpRM01BfDU0ZDA0ZTZiMDMzMzQzM2M1YTI3YTFiN2MxY2YwN2Q2NGYzMTlmNGJlMTEyNDZjMTExZWUxYTIxMTE1Yzk0NjI", url: "https://clicks.co.za/garnier_pure-active-ideal-complexion-daily-cream-40ml/p/229631" },
  { brand: 'Garnier', name: "Pure Active Daily Pore Scrub Wash 150ml", price: 169.6, step: 'Cleanse', tip: "Unclogs pores for breakout-prone skin.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDIzOTE2fGltYWdlL2pwZWd8YURGa0wyZzBOUzh4TURrd056YzRNVFV5T1RZek1BfGY3YTkyN2Y0N2M0ZjFhNmIwZTIyN2ZlOGZjZmI5ZTgwYWNlMmY3ZTc0MTE1N2I2NDA3MDEyYjY4YTI4MTVkYWQ", url: "https://clicks.co.za/garnier_pure-active-daily-pore-scrub-wash-150ml/p/882902" },
  { brand: 'Garnier', name: "Skin Active Micellar Cleansing Water 100ml", price: 71.99, step: 'Cleanse', tip: "Travel size for lectures and weekends away.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE3NjIzfGltYWdlL2pwZWd8YUdFMEwyaGtPQzh4TVRreE9UTTFNek0wT0RFeU5nfGZmMTNmZjQyMGYxNWZmNjA4ZjNjYWMyYzMxYWI5NzZmMTJlNTdhMGMzNTZjZjViNDA4ZGU5NTljNmM4YTM0ZGU", url: "https://clicks.co.za/garnier_skin-active-micellar-cleansing-water-100ml/p/302895" },
  { brand: 'Garnier', name: "Even & Matte Ideal Complexion Daily Cream 40ml", price: 77.7, step: 'Moisturize', tip: "Light daily cream for oily and combination skin.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDIxNzAyfGltYWdlL2pwZWd8YUdNMEwyZ3lZeTh4TVRrME5EazBOVGcwTkRJMU5BfDcwYTBlMzk5MjQyMjdjMTNkM2QzNzZlMGI1N2U3ZDQ3YzlmNzEyMGU4M2U5MzQ0MzQ4MTBmMzA1NGI4YmU1NmE", url: "https://clicks.co.za/garnier_even-and-matte-ideal-complexion-daily-cream-40ml/p/220827" },
  { brand: 'Garnier', name: "Micellar Cleansing Water 400ml", price: 123.2, step: 'Cleanse', tip: "Big bottle, gentle makeup remover for the budget.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE3MTYzfGltYWdlL2pwZWd8YUdJNEwyZzNPQzh4TVRrME1qRTBOelUxTlRNMU9BfDNmYzk2ZjcyOTk3MjE5ZjkwZmNhNjE3MzA2YmNmNTA5NDJiYzgzOTdlOGFiZTY1OWIxZmYxYzM5NGE3ZjJmZGM", url: "https://clicks.co.za/garnier_micellar-cleansing-water-400ml/p/242398" },
  { brand: 'Garnier', name: "Even & Matte Vitamin C Booster Serum 30ml", price: 188.3, step: 'Treat', tip: "Vitamin C for dark marks and uneven tone.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE5MDM2fGltYWdlL2pwZWd8YUdNNUwyZ3dNaTh4TWpBeU56RTFNRGN5T1RJME5nfDQ5MDM0NWI0YmUwZjZjNWVlZDhhMzRjMDRkOTMzNjlmZTRhYTM1ZTc3NGVjYWI5YzYxZmZjNDNjYTFhMTYzOWY", url: "https://clicks.co.za/garnier_even-and-matte-vitamin-c-booster-serum-30ml/p/349924" },
  { brand: 'Garnier', name: "Even & Matte SPF30 Day Cream 50ml", price: 105.7, step: 'Protect', tip: "Moisturizer and SPF30 in one step.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDIzMDg1fGltYWdlL2pwZWd8YUdNekwyaGhNUzh4TVRrME5qRXdNVEF4TkRVMU9BfDMyZTUxYjViNTk3YmQ3YWZjNGQ1MDhkYWMzYzNhMzliMGUyNDMwYTg3ODJiNzcyZTcxNWYyMWM0MTc5YzRiZWQ", url: "https://clicks.co.za/garnier_even-and-matte-spf30-day-cream-50ml/p/363012" },
  { brand: 'Garnier', name: "Pure Active AHA+BHA Charcoal Anti-Blemish Serum 30ml", price: 215.2, step: 'Treat', tip: "Targets blemishes and clogged pores.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE4MzQ2fGltYWdlL2pwZWd8YUdGakwyZzVZaTh4TURZNE5qZzVNVEEyTlRNM05BfGNjYzYwNmU1NWZmMzYzZTA2MmVhYzBmMzkxZmQyZmM2NTUxYjkyNjhkYWVlYzczMzMzZjg1ZDBkNWFiNGNkNzc", url: "https://clicks.co.za/garnier_pure-active-aha+bha-charcoal-anti-blemish-serum-30ml/p/368436" },
  { brand: 'Garnier', name: "Super UV Water Gel Sunscreen SPF50 30ml", price: 132.0, step: 'Protect', tip: "Water-light SPF50 that sits well under makeup.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDIwMDI2fGltYWdlL2pwZWd8YURNMUwyZzBPUzh4TVRZek9UWTROVEl4T0RNek5BfDgzYWExMmI3NjdkYTJmNGQ2NmNhNmE4MDUyZWQzZDgzMzc2OWFjMmZhMWI5YThhOWJhZGFjMTEwNjc5Mzg4Y2Q", url: "https://clicks.co.za/garnier_super-uv-water-gel-sunscreen-spf50-30ml/p/402566" },
  { brand: 'Garnier', name: "Pure Active Pimple Patches 22 Piece", price: 122.4, step: 'Treat', tip: "Cover a spot overnight so you do not pick it.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDIyODg5fGltYWdlL2pwZWd8YURnMkwyZzNNQzh4TVRneU1EQXhOREUzTkRJek9BfDdhMTViNzJlYWIyOWY0ZDg5ZjhkOTcxNjM3YmZjMjJjMmViNTgyMmQ2MjcwN2FmMDRkMWMzNDVmYWQ4MmY3MDg", url: "https://clicks.co.za/garnier_pure-active-pimple-patches-22-piece/p/398349" },
  { brand: 'Garnier', name: "Even & Matte Face Wash 100ml", price: 71.4, step: 'Cleanse', tip: "Foaming wash that keeps shine under control.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDIxNjE0fGltYWdlL2pwZWd8YURNMkwyZ3pZUzh4TVRFMk16VXlOekE0TmpFeE1BfGMxMGUyMTM2MzNmNTA1YWU2YWZlYTU1OWNhNjM5YTk5YTgwZmZjMGFlNWQ5ODNiOGFmZWI3MDY0Zjg3MzU3MTg", url: "https://clicks.co.za/garnier_even-and-matte-face-wash-100ml/p/51708" },
  { brand: 'CeraVe', name: "Hydrating Cleanser 236ml", price: 255.0, step: 'Cleanse', tip: "Gentle everyday wash for normal to dry skin.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE0NzkxfGltYWdlL2pwZWd8YUdFeUwyZzRaQzh4TWpBNE5qQXpNekF5TXpBd05nfDhiMjcxZjZlNWY4NDMzYzdjN2I5MjRjOWI2YmQyMzU3ODFjMzc2NDdkMzhlMmEzNWVjMDFkZTk0ZGE0ZTNhZjA", url: "https://clicks.co.za/cerave_hydrating-cleanser-for-normal-to-dry-skin-236ml/p/360499" },
  { brand: 'CeraVe', name: "Foaming Gel Cleanser 236ml", price: 255.0, step: 'Cleanse', tip: "Gel wash that cleans oily skin without stripping.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDEzMTY0fGltYWdlL2pwZWd8YUdJMUwyZzJaUzh4TWpBNE5qQXpNemswTURVeE1BfDgwM2NlYjkxMTUyMjI5YzU2YzJkMjBjMGZjODM1ZGQ2OTlhMTIzNDQ2MzU1NmI1Nzk0YzNhYmNmYTdjYTczMWM", url: "https://clicks.co.za/cerave_foaming-gel-cleanser-for-normal-to-oily-skin-236ml/p/360441" },
  { brand: 'CeraVe', name: "Foaming Facial Cleanser 473ml", price: 369.0, step: 'Cleanse', tip: "Big 473ml bottle, best value per wash for oily skin.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE0NzMyfGltYWdlL2pwZWd8YUdRd0wyZzJOeTh4TWpBNE5qQXpPRFkxT1RFd01nfGQyODQxYWQzM2FjYTliNTVkMzFlZmNiNzRlYzZlNWRmY2JkNjdlMjQ4YmIxYWQ0NzEwNDE0Yjk4OTNlYzA3MWQ", url: "https://clicks.co.za/cerave_foaming-facial-cleanser-for-normal-to-oily-skin-473ml/p/360498" },
  { brand: 'CeraVe', name: "SA Smoothing Cleanser 236ml", price: 285.0, step: 'Treat', tip: "Salicylic acid wash for rough, bumpy texture.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE4MTQ1fGltYWdlL2pwZWd8YURFekwyaGpNUzh4TWpBNE5qQTBORFk0T0RReE5BfDVhOTI5ZjIwNmQzODJjNjkyMTNjOGUzYzhhM2RlZTk1NDdlMjJiZjc1OGY0ZGU0MDMzOGQ2YzYxOTA2OTlkZDc", url: "https://clicks.co.za/cerave_sa-smoothing-cleanser-for-dry-rough-and-bumpy-skin-236ml/p/360502" },
  { brand: 'CeraVe', name: "Eye Repair Cream 14ml", price: 259.0, step: 'Treat', tip: "Soothes puffy, tired eyes after late-night study.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDEwMTY0fGltYWdlL2pwZWd8YUdRd0wyaGpaUzh4TWpBNE5qQXpOamsxTlRFMk5nfDRiZGFiZjdkMDYwMDc1ZjZlMDg5NjZlM2M3N2YxYjkyOGVmOTg1YjBiYTI1NmVjMjg5Y2E5ZTc3NGI3MzQ2Yjg", url: "https://clicks.co.za/cerave_eye-repair-cream-14ml/p/360439" },
  { brand: 'CeraVe', name: "Moisturizing Cream 340g", price: 299.0, step: 'Moisturize', tip: "Ceramide cream that keeps dry skin comfortable through cold, dry winters.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDI2NDMyfGltYWdlL2pwZWd8YURjM0wyZzJOQzh4TWpBNE5qQXpOVGt3TmpVNU1BfGFiYzdhZjJiYjhhZWMwMGM3ZWU0YjFkYTJkOTAwNzZkMDY5YzI5ODNlYjIzNGExODMxNjBkNDQ1MzQ2ZDJhOWY", url: "https://clicks.co.za/cerave_moisturizing-cream-for-normal-to-dry-skin-340g/p/360500" },
  { brand: 'CeraVe', name: "Moisturising Lotion 236ml", price: 275.0, step: 'Moisturize', tip: "Lightweight lotion for dry to very dry skin.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE1ODE2fGltYWdlL2pwZWd8YURWakwyZzBPUzh4TWpBNE5qQXpOVEV5TURFMU9BfGQ4ODk5ZjRkZjkzMjVjZjZkZDRkNzk2YjAwOTQ4YzExMDU0MDZhOGZlMmFmZmUzMTI3NGViMWQ5MWYzYmRjNTI", url: "https://clicks.co.za/cerave_moisturising-lotion-for-dry-to-very-dry-skin-236ml/p/360504" },
  { brand: 'CeraVe', name: "Facial Night Cream 52ml", price: 310.0, step: 'Moisturize', tip: "Night cream for normal to dry skin.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDEzMDUzfGltYWdlL2pwZWd8YUdZd0wyZzRNeTh4TWpBNE5qQTBNVFF4TVRZeE5BfGNkZjViYzgyOTVjMDk1N2U0ZDRmNTBmMzUxY2E3YjA5ZDc4YzM3N2YxNGU2MDZkM2EwNTk0MWE3ODRkNzMyNjA", url: "https://clicks.co.za/cerave_facial-moisturising-lotion-night-cream-for-normal-to-dry-skin-52ml/p/360440" },
  { brand: 'CeraVe', name: "Moisturizing Lotion SPF50 52ml", price: 309.0, step: 'Protect', tip: "Moisturiser with SPF50, two steps in one.", img: "https://clicks.co.za/medias/?context=bWFzdGVyfHByb2R1Y3QtaW1hZ2VzfDE0Njg3fGltYWdlL2pwZWd8YURjekwyZzJNUzh4TWpBNE5qQTBPRFE0T1RVd01nfGVjNmY4ZWVhM2Q0M2MwNTAzNDUwNTc1MGM2YTA1MmZjZTI1ZWY3YTZmZTZkZTRjNzgwZDM3MmZhODIwMmMxNjA", url: "https://clicks.co.za/cerave_moisturizing-lotion-spf50-52ml/p/373071" },
]

export const BRANDS: { name: ShelfBrand; tagline: string; about: string; stockist: string; url: string; best: string }[] = [
  { name: 'Portia M', tagline: 'Marula-based, locally loved', about: 'A Southern African range built around marula oil. The lowest prices on our shelf, with serums, toners and an SPF that fit a student budget.', stockist: 'portiamss.com', url: 'https://portiamss.com/', best: 'Best for tight budgets' },
  { name: 'Garnier', tagline: 'Clear skin, easy to find', about: 'Widely stocked at Clicks. Strong for oily and breakout-prone skin, with pore washes, vitamin C and patches that cover a spot overnight.', stockist: 'Clicks', url: 'https://clicks.co.za/brands/garnier-skincare', best: 'Best for oily, breakout-prone skin' },
  { name: 'CeraVe', tagline: 'Ceramide barrier care', about: 'Dermatologist-developed basics with ceramides. Gentle cleansers and rich creams for dry or sensitive skin that needs repair, at a higher price point.', stockist: 'Clicks', url: 'https://clicks.co.za/brands/cerave', best: 'Best for dry, sensitive skin' },
]

export interface Concern {
  label: string
  advice: string
  doctor?: boolean
  picks: string[]
}
/** Skin concerns: pharmacist advice plus names of products from SHELF. Not medical advice. */
export const CONCERNS: Concern[] = [
  { label: 'Acne and breakouts', advice: 'Go gentle and be consistent. Never pick; cover spots instead.', picks: ['Pure Active Daily Pore Scrub Wash 150ml', 'Pure Active AHA+BHA Charcoal Anti-Blemish Serum 30ml', 'Pure Active Pimple Patches 22 Piece'] },
  { label: 'Dark spots and hyperpigmentation', advice: 'Works on every skin tone. Daily SPF is essential or spots return. Fading takes 8–12 weeks.', picks: ['Even & Matte Vitamin C Booster Serum 30ml', 'VitaGlow Serum 50ml', 'Super UV Water Gel Sunscreen SPF50 30ml'] },
  { label: 'Eczema and very dry skin', advice: 'Moisturize right after washing. Avoid fragrance and hot water.', doctor: true, picks: ['Hydrating Cleanser 236ml', 'Moisturizing Cream 340g', 'Moisturising Lotion 236ml'] },
  { label: 'Rosacea and redness', advice: 'Keep it simple and fragrance-free. Introduce one product at a time.', doctor: true, picks: ['Face Wash Sulphate Free 150ml', 'Hydrating Cleanser 236ml', 'Marula Sunscreen Lotion'] },
  { label: 'Vitiligo', advice: 'Skin without pigment burns easily. SPF 50 daily on every patch, and reapply. Your skin is not a problem to fix.', doctor: true, picks: ['Super UV Water Gel Sunscreen SPF50 30ml', 'Moisturizing Lotion SPF50 52ml', 'Marula Sunscreen Lotion'] },
  { label: 'Scarring and keloids', advice: 'Protect healing skin from the sun and avoid picking. Keloids need a clinician.', doctor: true, picks: ['Rejuvenate + Serum 50ml', 'Pure Active Pimple Patches 22 Piece', 'Marula Sunscreen Lotion'] },
  { label: 'Razor bumps and rough texture', advice: 'Exfoliate gently a few times a week, not daily.', picks: ['SA Smoothing Cleanser 236ml', 'Pure Active AHA+BHA Charcoal Anti-Blemish Serum 30ml'] },
  { label: 'Dullness and dark circles', advice: 'Hydration and sleep first, then a brightening serum.', picks: ['HyaluraGlow Serum 50ml', 'VitaGlow Serum 50ml', 'Eye Repair Cream 14ml'] },
]

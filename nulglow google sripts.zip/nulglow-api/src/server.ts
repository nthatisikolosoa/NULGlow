import { createApp } from './app.js'
import { config } from './config.js'
import { openDb } from './db.js'
import { createMailer } from './services/mailer.js'

if (config.env === 'production' && !config.adminToken) console.warn('[warn] ADMIN_TOKEN is not set: /api/admin/* is disabled.')

const db = openDb(config.databasePath)
const app = createApp({ db, config, mailer: createMailer(config) })

const server = app.listen(config.port, () => {
  console.log(`NULGlow API listening on http://localhost:${config.port}  (db: ${config.databasePath})`)
})

const shutdown = () => {
  server.close(() => {
    db.close()
    process.exit(0)
  })
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)

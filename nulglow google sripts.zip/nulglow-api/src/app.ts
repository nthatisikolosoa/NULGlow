import cors from 'cors'
import express from 'express'
import helmet from 'helmet'
import { existsSync } from 'node:fs'
import { resolve } from 'node:path'
import type { Config } from './config.js'
import type { Db } from './db.js'
import { errorHandler, notFound } from './errors.js'
import { apiLimiter, formLimiter, requireAdmin } from './middleware.js'
import { adminRouter } from './routes/admin.js'
import { catalogRouter } from './routes/catalog.js'
import { formsRouter } from './routes/forms.js'
import { reviewsRouter } from './routes/reviews.js'
import type { Mailer } from './services/mailer.js'

export interface AppDeps {
  db: Db
  config: Config
  mailer: Mailer
  /** Tests turn rate limiting off so they can hammer endpoints. */
  rateLimit?: boolean
}

export function createApp({ db, config, mailer, rateLimit = true }: AppDeps) {
  const app = express()
  app.disable('x-powered-by')
  if (config.trustProxy) app.set('trust proxy', config.trustProxy)

  const serveFrontend = config.frontendDist && existsSync(resolve(config.frontendDist))
  app.use(
    helmet({
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      // Only matters when this server also serves the site: allow its Google Fonts and remote product/avatar images.
      contentSecurityPolicy: serveFrontend
        ? {
            directives: {
              'img-src': ["'self'", 'data:', 'https:'],
              'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
              'font-src': ["'self'", 'https://fonts.gstatic.com'],
              // The footer's "Find us" map is a Google Maps embed.
              'frame-src': ['https://www.google.com'],
              // Forcing https would break the site when you test over plain http://localhost on some browsers.
              'upgrade-insecure-requests': config.env === 'production' ? [] : null,
            },
          }
        : undefined,
    }),
  )
  app.use(cors({ origin: config.corsOrigins, methods: ['GET', 'POST', 'PATCH', 'DELETE'], allowedHeaders: ['Content-Type', 'Authorization'], maxAge: 86400 }))
  app.use(express.json({ limit: '20kb' }))

  const noop: express.RequestHandler = (_q, _s, n) => n()
  const api = express.Router()
  api.use(rateLimit ? apiLimiter : noop)

  api.get('/health', (_req, res) => {
    db.prepare('SELECT 1').get()
    res.json({ status: 'ok', time: new Date().toISOString() })
  })

  // Rate-limit only the endpoints that accept submissions.
  const strict = rateLimit ? formLimiter : noop
  api.post(['/contact', '/newsletter/subscribe', '/signup', '/reviews'], strict)

  api.use(catalogRouter())
  api.use('/reviews', reviewsRouter(db, config))
  api.use(formsRouter(db, config, mailer))
  api.use('/admin', requireAdmin(config.adminToken), adminRouter(db))
  api.use(notFound)

  app.use('/api', api)
  if (serveFrontend) app.use(express.static(resolve(config.frontendDist!)))
  app.use(notFound)
  app.use(errorHandler)
  return app
}

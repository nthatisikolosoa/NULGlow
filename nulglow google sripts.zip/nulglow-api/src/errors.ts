import type { ErrorRequestHandler, RequestHandler } from 'express'
import type { ZodType } from 'zod'

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public fields?: Record<string, string>,
  ) {
    super(message)
  }
}

/** Validate `data` with a zod schema; throws a 400 with a per-field message map the UI can show inline. */
export function parse<T>(schema: ZodType<T>, data: unknown): T {
  const r = schema.safeParse(data)
  if (r.success) return r.data
  const fields: Record<string, string> = {}
  for (const issue of r.error.issues) {
    const key = String(issue.path[0] ?? '_')
    fields[key] ??= issue.message
  }
  throw new HttpError(400, 'Please check the highlighted fields.', fields)
}

export const notFound: RequestHandler = (_req, res) => {
  res.status(404).json({ error: 'Not found' })
}

export const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  if (err instanceof HttpError) {
    res.status(err.status).json({ error: err.message, ...(err.fields ? { fields: err.fields } : {}) })
    return
  }
  // body-parser failures (bad JSON, payload too large)
  const status = (err as { status?: number }).status
  if (status && status >= 400 && status < 500) {
    res.status(status).json({ error: status === 413 ? 'Request too large.' : 'Invalid request body.' })
    return
  }
  console.error(err)
  res.status(500).json({ error: 'Something went wrong on our side. Please try again.' })
}

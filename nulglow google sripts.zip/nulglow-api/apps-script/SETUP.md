# Free forms backend: Google Sheet + Apps Script

About 10 minutes, no server, no card. You need a Google account (a normal Gmail is fine).

What you get: contact messages, newsletter sign-ups (with email confirmation), student sign-ups and reviews, all stored in a Google Sheet you own, with emails sent from your Google account.

## 1. Make the sheet
1. Go to **sheets.new** and name the spreadsheet `NULGlow data`. Leave it empty. The tabs (Reviews, Contact, Subscribers, Students) create themselves.

## 2. Add the script
1. In the sheet: **Extensions → Apps Script**.
2. Delete everything in the editor, then paste the full contents of `apps-script/Code.gs`.
3. At the top, edit the `CONFIG` block:
   - `CONTACT_INBOX`: where contact messages should arrive.
   - `SITE_URL`: your website address **ending in a slash**, e.g. `https://yourname.github.io/nulglow/`.
   - `REVIEWS_AUTO_APPROVE`: `true` shows new reviews immediately; `false` holds them for you (see "Moderating reviews").
4. Click **Save** (disk icon).

## 3. Publish it
1. **Deploy → New deployment**. Click the gear next to "Select type" and choose **Web app**.
2. Set **Execute as: Me** and **Who has access: Anyone**. (It must be "Anyone" so visitors' browsers can reach it. They can only submit forms and read approved reviews. They can never open your sheet.)
3. Click **Deploy**. Google asks you to authorize. You will see a warning like "Google hasn't verified this app". That is normal for your own script: click **Advanced → Go to (project name) (unsafe) → Allow**.
4. Copy the **Web app URL** (it ends in `/exec`).
5. Check it: open that URL in a browser. You should see `{"ok":true,"service":"NULGlow forms",...}`.

## 3b. Connect the website
In your GitHub repo: **Settings → Secrets and variables → Actions → Variables → New repository variable**
Name: `FORMS_URL` Value: the `/exec` URL. Then **Actions → Deploy website to GitHub Pages → Run workflow**.

Test it on the live site: send a contact message, subscribe, sign up, post a review. Rows appear in the sheet and emails arrive.

## Day-to-day
- **Moderating reviews:** set `REVIEWS_AUTO_APPROVE` to `false`. New reviews appear in the **Reviews** tab with Status `pending`. Change the cell to `approved` to publish, or `rejected` to hide. You can also change an approved one to hide it later.
- **Contact messages** arrive in your inbox (reply goes straight to the student) and are also logged in the **Contact** tab.
- **Newsletter list:** the **Subscribers** tab. Only rows with Status `confirmed` agreed to receive it.
- **Changing the script later:** edit, then **Deploy → Manage deployments → pencil icon → Version: New version → Deploy**. Saving alone does NOT update the live site, and a brand-new deployment would change the URL.

## Limits to know about
- A normal Gmail account can send about **100 emails a day** through Apps Script (a Google Workspace account can send more). The script keeps 25 of those free for contact messages: when the allowance runs low it skips confirmation/welcome emails but still saves every sign-up and still emails you contact messages. Check Google's current quota page if this matters to you.
- That also means you can't mail a weekly newsletter to more than ~100 people a day from this setup. If the list grows past that, export the confirmed rows to a newsletter service.
- Each address gets at most one confirmation email per 10 minutes, so the form can't be used to flood someone's inbox.
- Visitors can't see each other's emails: the public web address only returns approved reviews (name, course, text, rating).
- The emails you collect are personal data; keep the sheet private (don't share it publicly) and delete rows if someone asks.

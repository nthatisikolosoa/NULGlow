/**
 * NULGlow forms backend for Google Apps Script.
 *
 * Replaces the Node API when the website is hosted on GitHub Pages with no server.
 * Everything is stored in the Google Sheet this script is attached to, and emails
 * are sent from your Google account. See apps-script/SETUP.md for the 10-minute setup.
 *
 * Endpoints (all on the one web-app URL):
 *   POST  {action:'contact'|'subscribe'|'signup'|'review', ...}   -> JSON {ok, ...}
 *   GET   ?action=reviews                                         -> JSON {ok, reviews:[...]}
 *   GET   ?action=confirm&token=...      (link inside emails)     -> small HTML page
 *   GET   ?action=unsubscribe&token=...  (link inside emails)     -> small HTML page
 */

// ----------------------------- SETTINGS (edit these) -----------------------------
var CONFIG = {
  // Contact-form messages are emailed here.
  CONTACT_INBOX: 'clara.kolosoan@gmail.com',
  // Your public website address (where the confirm/unsubscribe pages link back to).
  SITE_URL: 'https://YOUR-USERNAME.github.io/YOUR-REPO/',
  // true  = new reviews appear on the site straight away.
  // false = they land in the sheet as "pending"; change the Status cell to "approved" to publish.
  REVIEWS_AUTO_APPROVE: true,
  // Leave empty when the script was created from inside the sheet (Extensions > Apps Script).
  SHEET_ID: '',
  // Keep this many emails of the daily quota free for contact-form notifications.
  RESERVE_FOR_CONTACT: 25
};
// ---------------------------------------------------------------------------------

var SHEETS = {
  Reviews: ['Created', 'Name', 'Course', 'Review', 'Rating', 'Status'],
  Contact: ['Created', 'Name', 'Email', 'Topic', 'Message', 'Handled'],
  Subscribers: ['Email', 'Status', 'ConfirmToken', 'UnsubToken', 'Source', 'Created', 'Confirmed'],
  Students: ['Email', 'Name', 'SkinType', 'Concerns', 'Created', 'Updated']
};
var TOPICS = ['Routine help', 'Store partnership', 'Hall plan', 'Something else'];
var SKIN_TYPES = ['Oily', 'Dry', 'Combination', 'Sensitive'];
var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
var TOKEN_RE = /^[a-f0-9]{48}$/;

// ================================= entry points =================================

function doPost(e) {
  try {
    var body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    var lock = LockService.getScriptLock();
    lock.waitLock(15000); // one write at a time so rows never collide
    try {
      switch (body.action) {
        case 'contact': return json_(contact_(body));
        case 'subscribe': return json_(subscribe_(body));
        case 'signup': return json_(signup_(body));
        case 'review': return json_(review_(body));
        default: return json_({ ok: false, error: 'Unknown action.' });
      }
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    if (err && err.isValidation) return json_({ ok: false, error: err.message, fields: err.fields });
    console.error(err && err.stack ? err.stack : err);
    return json_({ ok: false, error: 'Something went wrong on our side. Please try again.' });
  }
}

function doGet(e) {
  var p = (e && e.parameter) || {};
  try {
    if (p.action === 'reviews') return json_({ ok: true, reviews: approvedReviews_() });
    if (p.action === 'confirm') return confirm_(p.token);
    if (p.action === 'unsubscribe') return unsubscribe_(p.token);
    return json_({ ok: true, service: 'NULGlow forms', time: new Date().toISOString() });
  } catch (err) {
    console.error(err && err.stack ? err.stack : err);
    return json_({ ok: false, error: 'Something went wrong on our side.' });
  }
}

// ================================= handlers =================================

function contact_(b) {
  var v = validate_({
    name: line_(b.name, 2, 80, 'Enter your name (2+ characters).'),
    email: email_(b.email),
    topic: topic_(b.topic),
    message: text_(b.message, 10, 2000, 'Tell us a little more (10+ characters).')
  });
  if (b.website) return { ok: true }; // honeypot: a bot filled the hidden field

  append_('Contact', [now_(), v.name, v.email, v.topic, v.message, 'no']);
  // The message is already saved, so a mail failure must never lose it or fail the request.
  try {
    MailApp.sendEmail({
      to: CONFIG.CONTACT_INBOX,
      replyTo: v.email,
      subject: oneLine_('[NULGlow] ' + v.topic + ': message from ' + v.name),
      body: 'From: ' + v.name + ' <' + v.email + '>\nTopic: ' + v.topic + '\n\n' + v.message + '\n'
    });
  } catch (err) {
    console.error('contact mail failed: ' + err);
  }
  return { ok: true, message: 'Thanks, ' + firstName_(v.name) + '. Message sent. We reply within two working days.' };
}

function subscribe_(b) {
  var v = validate_({ email: email_(b.email) });
  // Identical answer for everyone so the form can't be used to discover who is subscribed.
  var done = { ok: true, message: "You're in. Check your inbox to confirm." };
  if (b.website) return done;
  var sub = startSubscription_(v.email, 'footer');
  if (sub) {
    sendConfirmation_(sub.email, sub.confirm,
      'Confirm your NULGlow weekly drop',
      'Hi!\n\nTap the link to confirm your subscription to the NULGlow weekly drop (student deals + one pharmacist tip, every Friday):\n\n' + confirmUrl_(sub.confirm) + '\n\nIf you didn\'t ask for this, just ignore this email.\n');
  }
  return done;
}

function signup_(b) {
  var v = validate_({
    name: line_(b.name, 1, 80, 'Please enter your name.'),
    email: email_(b.email),
    skinType: skin_(b.skinType),
    concerns: optional_(b.concerns, 200)
  });
  if (b.website) return { ok: true, message: 'Welcome, ' + firstName_(v.name) + '.' };

  // Upsert: signing up twice updates the same row and keeps earlier optional answers.
  var sh = sheet_('Students');
  var rows = sh.getDataRange().getValues();
  var found = -1;
  for (var i = 1; i < rows.length; i++) if (String(rows[i][0]).toLowerCase() === v.email) { found = i + 1; break; }
  if (found > 0) {
    var old = rows[found - 1];
    put_(sh, found, 2, [[v.name, v.skinType || old[2], v.concerns || old[3]]]);
    put_(sh, found, 6, [[now_()]]);
  } else {
    append_('Students', [v.email, v.name, v.skinType, v.concerns, now_(), now_()]);
  }

  var sub = startSubscription_(v.email, 'signup');
  sendConfirmation_(v.email, sub && sub.confirm, 'Welcome to NULGlow',
    'Hi ' + firstName_(v.name) + ',\n\nWelcome to NULGlow! Build your routine any time at ' + CONFIG.SITE_URL + '#/recommendations\n\n' +
    (sub ? 'To get the weekly deals email, confirm here:\n' + confirmUrl_(sub.confirm) + '\n\n' : '') +
    'Free skin consults run every Wednesday, 12:00-16:00, at Mzalas Complex Pharmacy. No booking needed.\n');
  return { ok: true, message: 'Welcome, ' + firstName_(v.name) + ". We'll send student deals and routine tips to " + v.email + '.' };
}

function review_(b) {
  var rating = Number(b.rating === undefined || b.rating === '' ? 5 : b.rating);
  var v = validate_({
    name: line_(b.name, 1, 80, 'Please add your name.'),
    quote: text_(b.quote, 15, 300, 'Tell us a little more (at least 15 characters).'),
    rating: (rating >= 1 && rating <= 5 && rating === Math.floor(rating)) ? rating : fail_('Choose a rating from 1 to 5.')
  });
  var course = String(b.course || '').replace(/[\u0000-\u001F\u007F]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'NUL student';
  if (b.website) return { ok: true, published: true };

  var status = CONFIG.REVIEWS_AUTO_APPROVE ? 'approved' : 'pending';
  var created = now_();
  append_('Reviews', [created, v.name, course, v.quote, String(v.rating), status]);
  return { ok: true, published: status === 'approved', review: { name: v.name, course: course, quote: v.quote, rating: v.rating, createdAt: created } };
}

function approvedReviews_() {
  var rows = sheet_('Reviews').getDataRange().getValues();
  var out = [];
  for (var i = rows.length - 1; i >= 1; i--) { // newest first
    var r = rows[i];
    if (String(r[5]).trim().toLowerCase() !== 'approved') continue;
    out.push({ name: String(r[1]), course: String(r[2]), quote: String(r[3]), rating: Number(r[4]) || 5, createdAt: String(r[0]) });
    if (out.length >= 100) break;
  }
  return out;
}

// ----------------------------- newsletter plumbing -----------------------------

/** Create a pending subscriber (or re-arm a pending/unsubscribed one). Returns null if already confirmed. */
function startSubscription_(emailAddr, source) {
  var sh = sheet_('Subscribers');
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).toLowerCase() !== emailAddr) continue;
    if (rows[i][1] === 'confirmed') return null;
    put_(sh, i + 1, 2, [['pending']]);
    return { email: emailAddr, confirm: String(rows[i][2]) };
  }
  var confirm = token_(), unsub = token_();
  append_('Subscribers', [emailAddr, 'pending', confirm, unsub, source, now_(), '']);
  return { email: emailAddr, confirm: confirm };
}

function confirm_(t) { return setStatus_(t, 2, 'confirmed', "You're subscribed", 'Thanks for confirming. Look out for the weekly drop every Friday.'); }
function unsubscribe_(t) { return setStatus_(t, 3, 'unsubscribed', 'Unsubscribed', "You won't get the weekly drop any more. You can re-subscribe any time from the site footer."); }

function setStatus_(t, tokenCol, status, title, message) {
  if (!TOKEN_RE.test(String(t || ''))) return page_('Link not found', 'This link is invalid or has expired.');
  var sh = sheet_('Subscribers');
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][tokenCol]) !== t) continue;
    put_(sh, i + 1, 2, [[status]]);
    if (status === 'confirmed') put_(sh, i + 1, 7, [[now_()]]);
    return page_(title, message);
  }
  return page_('Link not found', 'This link is invalid or has expired.');
}

/**
 * Confirmation / welcome emails use the free daily quota (100 recipients on a normal Gmail account),
 * so they are skipped when the quota is low and throttled to one per address per 10 minutes.
 * That stops someone from using the form to flood a stranger's inbox or use up your allowance.
 */
function sendConfirmation_(to, hasToken, subject, body) {
  try {
    if (MailApp.getRemainingDailyQuota() <= CONFIG.RESERVE_FOR_CONTACT) return;
    var cache = CacheService.getScriptCache();
    var key = 'mail_' + to;
    if (cache.get(key)) return;
    cache.put(key, '1', 600);
    MailApp.sendEmail({ to: to, subject: oneLine_(subject), body: body });
  } catch (err) {
    console.error('mail failed: ' + err);
  }
}

// ================================= validation =================================
// Same rules and wording as the website and the Node API, so errors read identically everywhere.

function ValidationError(fields) {
  this.isValidation = true;
  this.fields = fields;
  this.message = 'Please check the highlighted fields.';
}
function fail_(msg) { return { __error: msg }; }

/** Collects every field error before throwing, so the form can show them all at once. */
function validate_(fields) {
  var errors = {}, clean = {}, bad = false;
  for (var k in fields) {
    var v = fields[k];
    if (v && v.__error) { errors[k] = v.__error; bad = true; } else clean[k] = v;
  }
  if (bad) throw new ValidationError(errors);
  return clean;
}
function strip_(s) { return String(s === undefined || s === null ? '' : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ''); }
function oneLine_(s) { return strip_(s).replace(/\s+/g, ' ').trim(); }
function line_(v, min, max, msg) {
  if (typeof v !== 'string') return fail_(msg);
  var s = oneLine_(v);
  return s.length < min ? fail_(msg) : s.length > max ? fail_('Keep this under ' + max + ' characters.') : s;
}
function text_(v, min, max, msg) {
  if (typeof v !== 'string') return fail_(msg);
  var s = strip_(v).trim();
  return s.length < min ? fail_(msg) : s.length > max ? fail_('Keep this under ' + max + ' characters.') : s;
}
function email_(v) {
  var msg = 'Enter a valid email address.';
  if (typeof v !== 'string') return fail_(msg);
  var s = v.trim().toLowerCase();
  return s.length > 254 || !EMAIL_RE.test(s) ? fail_(msg) : s;
}
function topic_(v) {
  if (v === undefined || v === '') return TOPICS[0];
  return TOPICS.indexOf(v) >= 0 ? v : fail_('Choose one of: ' + TOPICS.join(', ') + '.');
}
function skin_(v) {
  var s = typeof v === 'string' ? v.trim() : '';
  return !s ? '' : SKIN_TYPES.indexOf(s) >= 0 ? s : fail_('Skin type must be one of: ' + SKIN_TYPES.join(', ') + '.');
}
function optional_(v, max) { return oneLine_(v).slice(0, max); }
function firstName_(name) { return String(name).split(' ')[0]; }

// ================================= sheet + misc helpers =================================

function ss_() { return CONFIG.SHEET_ID ? SpreadsheetApp.openById(CONFIG.SHEET_ID) : SpreadsheetApp.getActiveSpreadsheet(); }

function sheet_(name) {
  var ss = ss_();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(SHEETS[name]);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, SHEETS[name].length).setFontWeight('bold');
  }
  return sh;
}

/**
 * Write cells as plain TEXT. Without this, anything a visitor types that starts with "=" would be
 * evaluated as a spreadsheet formula (a known injection trick), e.g. =IMPORTXML(...) in a review.
 */
function put_(sh, row, col, values) {
  var range = sh.getRange(row, col, values.length, values[0].length);
  range.setNumberFormat('@');
  range.setValues(values);
}
function append_(name, values) {
  var sh = sheet_(name);
  put_(sh, sh.getLastRow() + 1, 1, [values]);
}

function token_() {
  return (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '').slice(0, 48);
}
function now_() { return new Date().toISOString(); }
function confirmUrl_(t) { return ScriptApp.getService().getUrl() + '?action=confirm&token=' + t; }

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function esc_(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function page_(title, message) {
  return HtmlService.createHtmlOutput(
    '<!doctype html><html><head><base target="_top"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<style>body{font-family:system-ui,sans-serif;background:#fdf2f6;color:#3b1d33;display:grid;place-items:center;min-height:90vh;margin:0;padding:1rem}' +
    'main{max-width:28rem;background:#fff;padding:2.5rem;border-radius:1.5rem;text-align:center;box-shadow:0 12px 40px rgba(157,78,124,.18)}a{color:#9d4e7c;font-weight:600}</style></head>' +
    '<body><main><h1>' + esc_(title) + '</h1><p>' + esc_(message) + '</p><p><a href="' + esc_(CONFIG.SITE_URL) + '" target="_top">Back to NULGlow</a></p></main></body></html>'
  ).setTitle(title + ' | NULGlow');
}

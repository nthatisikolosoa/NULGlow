/**
 * Local stand-in for a deployed Apps Script web app, so the website can be tried end-to-end without Google.
 * It runs the REAL apps-script/Code.gs (via the in-memory Google fakes) and copies the HTTP quirks that matter:
 *   - every request is answered with a 302 to a DIFFERENT origin, which serves the result (like script.googleusercontent.com)
 *   - OPTIONS (CORS preflight) is not supported -> a client that sends application/json would break here, as on Google
 *   - errors are still HTTP 200 with {ok:false}
 * Extra dev endpoint: GET /__dump returns everything "in the sheet" and every email "sent".
 */
import { createServer, type Server } from 'node:http'
import { createEnv } from './gas-harness.js'

export function startSim(port: number, config: Record<string, unknown> = {}) {
  const t = createEnv({ config })
  const results = new Map<number, { type: string; body: string }>()
  let n = 0
  const stats = { preflights: 0, posts: 0, contentTypes: new Set<string>() }
  const echoPort = port + 1

  const main: Server = createServer((req, res) => {
    const url = new URL(req.url ?? '/', `http://localhost:${port}`)
    if (req.method === 'OPTIONS') { stats.preflights++; res.writeHead(405).end(); return }
    if (url.pathname === '/__dump') {
      res.writeHead(200, { 'content-type': 'application/json', 'access-control-allow-origin': '*' })
      res.end(JSON.stringify({ stats: { ...stats, contentTypes: [...stats.contentTypes] }, sent: t.sent, sheets: Object.fromEntries([...t.sheets].map(([k, v]) => [k, v.rows])) }))
      return
    }
    if (url.pathname !== '/macros/s/TEST/exec') { res.writeHead(404).end(); return }
    const respond = (type: string, body: string) => {
      const id = ++n
      results.set(id, { type, body })
      res.writeHead(302, { location: `http://localhost:${echoPort}/macros/echo?id=${id}`, 'access-control-allow-origin': '*' }).end()
    }
    const run = (body: string) => {
      if (req.method === 'POST') {
        stats.posts++
        stats.contentTypes.add((req.headers['content-type'] ?? '(none)').split(';')[0]!)
        const out = t.post(body)
        return respond('application/json', JSON.stringify(out))
      }
      const out = t.get(Object.fromEntries(url.searchParams)) as { getContent?: () => string; html?: string }
      respond(out.html ? 'text/html' : 'application/json', out.html ?? out.getContent!())
    }
    if (req.method === 'POST') {
      let body = ''
      req.on('data', (c) => (body += c)).on('end', () => run(body))
    } else run('')
  })

  const echo: Server = createServer((req, res) => {
    const id = Number(new URL(req.url ?? '/', 'http://x').searchParams.get('id'))
    const r = results.get(id)
    if (!r) { res.writeHead(404).end(); return }
    res.writeHead(200, { 'content-type': `${r.type}; charset=utf-8`, 'access-control-allow-origin': '*' }).end(r.body)
  })

  main.listen(port)
  echo.listen(echoPort)
  return { env: t, stats, close: () => { main.close(); echo.close() } }
}

// CLI: `npx tsx tests/gas-sim.ts 3081`
if (process.argv[1]?.endsWith('gas-sim.ts')) {
  const port = Number(process.argv[2] ?? 3081)
  startSim(port)
  console.log(`Apps Script simulator on http://localhost:${port}/macros/s/TEST/exec  (redirect target on :${port + 1})`)
}

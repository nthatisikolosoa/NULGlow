import { describe, expect, it } from 'vitest'
import { FORMULA, FakeSheet, createEnv } from './gas-harness.js'

const tokenIn = (text: string, action: 'confirm' | 'unsubscribe' = 'confirm') => new RegExp(`action=${action}&token=([a-f0-9]{48})`).exec(text)?.[1]

describe('test harness sanity', () => {
  it('the fake sheet really does flag unprotected formulas (so the injection tests mean something)', () => {
    const s = new FakeSheet('x')
    s.getRange(1, 1, 1, 1).setValues([['=IMPORTXML("evil")']])
    expect(s.rows[0]![0]).toBe(FORMULA)
    s.getRange(2, 1, 1, 1).setNumberFormat('@').setValues([['=IMPORTXML("evil")']])
    expect(s.rows[1]![0]).toBe('=IMPORTXML("evil")')
  })
})

describe('reviews', () => {
  it('starts empty, then a new review is stored and listed newest first', () => {
    const t = createEnv()
    expect(t.getJson({ action: 'reviews' })).toEqual({ ok: true, reviews: [] })
    const a = t.post({ action: 'review', name: '  Lerato  ', quote: 'This routine really calmed my skin down!', rating: 4 })
    expect(a).toMatchObject({ ok: true, published: true, review: { name: 'Lerato', course: 'NUL student', rating: 4 } })
    t.post({ action: 'review', name: 'Thabo', course: 'Law,  Year 1', quote: 'Great shelf, saved me a lot of money.', rating: 5 })
    const list = t.getJson({ action: 'reviews' }).reviews
    expect(list.map((r: { name: string }) => r.name)).toEqual(['Thabo', 'Lerato'])
    expect(list[0]).toMatchObject({ course: 'Law, Year 1', rating: 5 })
  })

  it('validates with the same wording as the website', () => {
    const t = createEnv()
    const r = t.post({ action: 'review', name: '', quote: 'too short', rating: 9 })
    expect(r.ok).toBe(false)
    expect(r.fields).toEqual({ name: 'Please add your name.', quote: 'Tell us a little more (at least 15 characters).', rating: 'Choose a rating from 1 to 5.' })
    expect(t.sheet('Reviews')).toBeUndefined() // nothing stored
  })

  it('moderation mode: pending until the owner edits the Status cell to "approved"', () => {
    const t = createEnv({ config: { REVIEWS_AUTO_APPROVE: false } })
    const r = t.post({ action: 'review', name: 'Mpho', quote: 'Lovely recommendations, thank you!' })
    expect(r.published).toBe(false)
    expect(t.getJson({ action: 'reviews' }).reviews).toHaveLength(0)
    t.sheet('Reviews')!.rows[1]![5] = 'Approved ' // the owner types it by hand: case and spaces must not matter
    expect(t.getJson({ action: 'reviews' }).reviews).toHaveLength(1)
  })

  it('a review that starts with = is stored as text, never evaluated as a formula', () => {
    const t = createEnv()
    t.post({ action: 'review', name: '=HYPERLINK("http://evil","x")', quote: '=IMPORTXML("http://evil.example","//a") padding', rating: 5 })
    expect(t.allCells()).not.toContain(FORMULA)
    expect(t.getJson({ action: 'reviews' }).reviews[0].quote).toContain('=IMPORTXML')
  })

  it('honeypot submissions are dropped silently', () => {
    const t = createEnv()
    expect(t.post({ action: 'review', name: 'Bot', quote: 'buy cheap pills now now now', website: 'http://spam' }).ok).toBe(true)
    expect(t.sheet('Reviews')).toBeUndefined()
  })
})

describe('contact', () => {
  it('stores the message and emails the inbox with reply-to set', () => {
    const t = createEnv()
    const r = t.post({ action: 'contact', name: 'Nthati Kolo', email: 'Nthati@NUL.ls', topic: 'Hall plan', message: 'Do you offer a hall discount for 6 people?' })
    expect(r).toEqual({ ok: true, message: 'Thanks, Nthati. Message sent. We reply within two working days.' })
    expect(t.sheet('Contact')!.rows[1]!.slice(1)).toEqual(['Nthati Kolo', 'nthati@nul.ls', 'Hall plan', 'Do you offer a hall discount for 6 people?', 'no'])
    expect(t.sent).toHaveLength(1)
    expect(t.sent[0]).toMatchObject({ to: 'inbox@example.com', replyTo: 'nthati@nul.ls' })
  })

  it('returns per-field errors with the website wording and stores nothing', () => {
    const t = createEnv()
    const r = t.post({ action: 'contact', name: 'A', email: 'nope', message: 'short' })
    expect(r.fields).toEqual({ name: 'Enter your name (2+ characters).', email: 'Enter a valid email address.', message: 'Tell us a little more (10+ characters).' })
    expect(t.sent).toHaveLength(0)
    expect(t.sheet('Contact')).toBeUndefined()
  })

  it('rejects unknown topics; defaults a missing topic', () => {
    const t = createEnv()
    expect(t.post({ action: 'contact', name: 'Ann', email: 'a@b.co', topic: 'Hax', message: 'a long enough message' }).ok).toBe(false)
    expect(t.post({ action: 'contact', name: 'Ann', email: 'a@b.co', message: 'a long enough message' }).ok).toBe(true)
    expect(t.sheet('Contact')!.rows[1]![3]).toBe('Routine help')
  })

  it('header-injection attempt collapses to one line', () => {
    const t = createEnv()
    t.post({ action: 'contact', name: 'Eve\r\nBcc: x@evil.com', email: 'e@e.co', message: 'hello there, this is a test' })
    expect(t.sent[0]!.subject).not.toMatch(/[\r\n]/)
    expect(t.sheet('Contact')!.rows[1]![1]).toBe('Eve Bcc: x@evil.com')
  })

  it('a mail failure (quota exhausted) never loses the message', () => {
    const t = createEnv()
    t.env.failMail = true
    expect(t.post({ action: 'contact', name: 'Ann', email: 'a@b.co', message: 'this must still be saved' }).ok).toBe(true)
    expect(t.sheet('Contact')!.rows).toHaveLength(2)
  })

  it('formula-looking input is stored as text', () => {
    const t = createEnv()
    t.post({ action: 'contact', name: '=cmd|calc', email: 'a@b.co', message: '=HYPERLINK("http://evil","click me please")' })
    expect(t.allCells()).not.toContain(FORMULA)
  })
})

describe('newsletter (double opt-in)', () => {
  it('subscribe -> confirm -> unsubscribe', () => {
    const t = createEnv()
    expect(t.post({ action: 'subscribe', email: 'Mpho@nul.ls' })).toEqual({ ok: true, message: "You're in. Check your inbox to confirm." })
    expect(t.sheet('Subscribers')!.rows[1]!.slice(0, 2)).toEqual(['mpho@nul.ls', 'pending'])
    const confirm = tokenIn(t.sent[0]!.body)!
    expect(t.get({ action: 'confirm', token: confirm }).title).toMatch(/subscribed/)
    expect(t.sheet('Subscribers')!.rows[1]![1]).toBe('confirmed')
    expect(t.sheet('Subscribers')!.rows[1]![6]).toBeTruthy()
    const unsub = t.sheet('Subscribers')!.rows[1]![3] as string
    expect(t.get({ action: 'unsubscribe', token: unsub }).title).toMatch(/Unsubscribed/)
    expect(t.sheet('Subscribers')!.rows[1]![1]).toBe('unsubscribed')
  })

  it('gives an identical answer for new and already-confirmed addresses (no enumeration), and no duplicate rows', () => {
    const t = createEnv()
    const a = t.post({ action: 'subscribe', email: 'x@nul.ls' })
    t.get({ action: 'confirm', token: tokenIn(t.sent[0]!.body)! })
    const before = t.sent.length
    expect(t.post({ action: 'subscribe', email: 'x@nul.ls' })).toEqual(a)
    expect(t.sent.length).toBe(before)
    expect(t.sheet('Subscribers')!.rows).toHaveLength(2)
  })

  it('re-subscribing after unsubscribing sends a fresh confirmation', () => {
    const t = createEnv()
    t.post({ action: 'subscribe', email: 'y@nul.ls' })
    t.get({ action: 'confirm', token: tokenIn(t.sent[0]!.body)! })
    t.get({ action: 'unsubscribe', token: t.sheet('Subscribers')!.rows[1]![3] as string })
    t.cache.clear() // pretend the 10-minute throttle has passed
    t.post({ action: 'subscribe', email: 'y@nul.ls' })
    expect(t.sheet('Subscribers')!.rows[1]![1]).toBe('pending')
    expect(t.sent).toHaveLength(2)
  })

  it('bad or unknown tokens show a friendly page and change nothing', () => {
    const t = createEnv()
    t.post({ action: 'subscribe', email: 'z@nul.ls' })
    for (const token of ['abc', '0'.repeat(48), '', undefined as unknown as string]) {
      expect(t.get({ action: 'confirm', token }).html).toMatch(/Link not found/)
    }
    expect(t.sheet('Subscribers')!.rows[1]![1]).toBe('pending')
  })

  it('rejects bad emails', () => {
    const t = createEnv()
    expect(t.post({ action: 'subscribe', email: 'nope' }).fields).toEqual({ email: 'Enter a valid email address.' })
  })
})

describe('email protection', () => {
  it('throttles confirmation emails to one per address per window (cannot be used to flood a stranger)', () => {
    const t = createEnv()
    for (let i = 0; i < 5; i++) t.post({ action: 'subscribe', email: 'victim@example.com' })
    expect(t.sent).toHaveLength(1)
  })

  it('stops sending confirmations when the daily quota is low, but contact messages still get through', () => {
    const t = createEnv()
    t.env.quota = 20 // below the 25 reserved for contact notifications
    t.post({ action: 'subscribe', email: 'a@nul.ls' })
    t.post({ action: 'signup', name: 'Ann', email: 'b@nul.ls' })
    expect(t.sent).toHaveLength(0)
    expect(t.sheet('Subscribers')!.rows).toHaveLength(3) // still recorded
    t.post({ action: 'contact', name: 'Ann', email: 'c@nul.ls', message: 'please still reach me' })
    expect(t.sent).toHaveLength(1)
  })
})

describe('signup', () => {
  it('creates a student and sends one welcome email carrying the confirm link', () => {
    const t = createEnv()
    const r = t.post({ action: 'signup', name: 'Palesa Mokoena', email: 'palesa@nul.ls', skinType: 'Oily', concerns: 'Acne' })
    expect(r.message).toMatch(/Welcome, Palesa/)
    expect(t.sheet('Students')!.rows[1]!.slice(0, 4)).toEqual(['palesa@nul.ls', 'Palesa Mokoena', 'Oily', 'Acne'])
    expect(t.sent).toHaveLength(1)
    expect(t.sent[0]!.body).toContain('https://site.example/repo/#/recommendations')
    expect(tokenIn(t.sent[0]!.body)).toBeTruthy()
  })

  it('signing up twice updates instead of duplicating, and keeps earlier optional answers', () => {
    const t = createEnv()
    t.post({ action: 'signup', name: 'Palesa', email: 'palesa@nul.ls', skinType: 'Dry', concerns: 'Eczema' })
    t.post({ action: 'signup', name: 'Palesa M', email: 'PALESA@nul.ls', skinType: '' })
    expect(t.sheet('Students')!.rows).toHaveLength(2)
    expect(t.sheet('Students')!.rows[1]!.slice(0, 4)).toEqual(['palesa@nul.ls', 'Palesa M', 'Dry', 'Eczema'])
    expect(t.sheet('Subscribers')!.rows).toHaveLength(2)
  })

  it('validates', () => {
    const t = createEnv()
    const r = t.post({ action: 'signup', name: '', email: 'bad', skinType: 'Purple' })
    expect(Object.keys(r.fields).sort()).toEqual(['email', 'name', 'skinType'])
  })
})

describe('robustness', () => {
  it('unknown action and malformed bodies return JSON errors, never throw', () => {
    const t = createEnv()
    expect(t.post({ action: 'nope' })).toEqual({ ok: false, error: 'Unknown action.' })
    const bad = t.post('{not json')
    expect(bad.ok).toBe(false)
    expect(bad.error).toMatch(/went wrong/)
  })

  it('health check on a plain GET', () => {
    expect(createEnv().getJson({})).toMatchObject({ ok: true, service: 'NULGlow forms' })
  })

  it('HTML pages escape the site URL', () => {
    const t = createEnv({ config: { SITE_URL: 'https://x.example/"><script>alert(1)</script>' } })
    expect(t.get({ action: 'confirm', token: 'bad' }).html).not.toContain('<script>')
  })
})

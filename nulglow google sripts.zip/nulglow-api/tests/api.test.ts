import request from 'supertest'
import { beforeEach, describe, expect, it } from 'vitest'
import { createApp } from '../src/app.js'
import { config as baseConfig, type Config } from '../src/config.js'
import { openDb, type Db } from '../src/db.js'
import { SHELF } from '../src/data/catalog.js'
import type { Mail, Mailer } from '../src/services/mailer.js'

const ADMIN = 'test-admin-token'
let db: Db
let sent: Mail[]
let cfg: Config

const build = (over: Partial<Config> = {}) => {
  cfg = { ...baseConfig, adminToken: ADMIN, reviewsAutoApprove: true, contactInbox: 'inbox@example.com', ...over }
  const mailer: Mailer = { async send(m) { sent.push(m) } }
  return createApp({ db, config: cfg, mailer, rateLimit: false })
}
beforeEach(() => {
  db = openDb(':memory:')
  sent = []
})

describe('catalog', () => {
  it('health check', async () => {
    const res = await request(build()).get('/api/health').expect(200)
    expect(res.body.status).toBe('ok')
  })

  it('lists and filters products', async () => {
    const app = build()
    const all = await request(app).get('/api/products').expect(200)
    expect(all.body.total).toBe(SHELF.length)
    expect(all.body.products.length).toBeGreaterThan(20)
    expect(new Set(all.body.products.map((p: { id: string }) => p.id)).size).toBe(all.body.products.length) // ids unique

    const cera = await request(app).get('/api/products?brand=CeraVe&step=Cleanse').expect(200)
    expect(cera.body.products.every((p: { brand: string; step: string }) => p.brand === 'CeraVe' && p.step === 'Cleanse')).toBe(true)

    const sorted = await request(app).get('/api/products?sort=price_asc&limit=3').expect(200)
    const prices = sorted.body.products.map((p: { price: number }) => p.price)
    expect(prices).toEqual([...prices].sort((a: number, b: number) => a - b))
    expect(prices).toHaveLength(3)

    await request(app).get('/api/products?brand=Nivea').expect(400)
  })

  it('brands include product counts and Maloti price range', async () => {
    const { body } = await request(build()).get('/api/brands').expect(200)
    const portia = body.brands.find((b: { name: string }) => b.name === 'Portia M')
    expect(portia.productCount).toBe(12)
    expect(portia.priceRange).toEqual({ min: 64, max: 198 })
  })

  it('builds a routine with a server-side total (matches the frontend maths)', async () => {
    const { body } = await request(build()).get('/api/routines').query({ skin: 'Combination', budget: 'Under M550' }).expect(200)
    expect(body.steps.map((s: { step: string }) => s.step)).toEqual(['Cleanse', 'Treat', 'Moisturize', 'Protect'])
    const sum = body.steps.reduce((s: number, x: { product: { price: number } }) => s + x.product.price, 0)
    expect(body.total).toBe(sum)
    expect(body.productCount).toBe(4)
  })

  it('routine can include resolved concern advice with product picks', async () => {
    const { body } = await request(build()).get('/api/routines').query({ skin: 'Oily', budget: 'Under M300', concerns: 'Acne and breakouts,Vitiligo' }).expect(200)
    expect(body.concerns).toHaveLength(2)
    const acne = body.concerns.find((c: { label: string }) => c.label === 'Acne and breakouts')
    expect(acne.picks).toHaveLength(3)
    expect(acne.picks[0].url).toMatch(/^https:/)
    const vit = body.concerns.find((c: { label: string }) => c.label === 'Vitiligo')
    expect(vit.seeDoctor).toBe(true)
  })

  it('every concern pick resolves to a real product', async () => {
    const { body } = await request(build()).get('/api/concerns').expect(200)
    for (const c of body.concerns) {
      expect(c.picks.length).toBeGreaterThan(0)
    }
    const { CONCERNS } = await import('../src/data/catalog.js')
    for (const c of body.concerns) {
      const src = CONCERNS.find((x) => x.label === c.label)!
      expect(c.picks).toHaveLength(src.picks.length) // none silently dropped
    }
  })

  it('rejects bad routine params', async () => {
    const app = build()
    await request(app).get('/api/routines?skin=Purple&budget=Under M300').expect(400)
    await request(app).get('/api/routines?skin=Oily').expect(400)
    await request(app).get('/api/routines?skin=Oily&budget=Under M300&concerns=Nonsense').expect(400)
  })

  it('serves deals, plans, stats', async () => {
    const app = build()
    expect((await request(app).get('/api/deals').expect(200)).body.deals).toHaveLength(6)
    expect((await request(app).get('/api/deals?store=Campus Pharmacy').expect(200)).body.deals).toHaveLength(1)
    expect((await request(app).get('/api/plans').expect(200)).body.plans.map((p: { name: string }) => p.name)).toEqual(['Starter', 'Glow', 'Hall'])
    expect((await request(app).get('/api/stats').expect(200)).body.stats).toHaveLength(4)
  })

  it('unknown api route is a JSON 404', async () => {
    const res = await request(build()).get('/api/nope').expect(404)
    expect(res.body.error).toBe('Not found')
  })
})

describe('reviews', () => {
  it('returns the 4 seeded reviews', async () => {
    const { body } = await request(build()).get('/api/reviews').expect(200)
    expect(body.count).toBe(4)
    expect(body.reviews[0].name).toBe('Amara O.')
  })

  it('a new review goes first and sanitises input', async () => {
    const app = build()
    const post = await request(app).post('/api/reviews').send({ name: '  Lerato  ', quote: 'This routine really calmed my skin down!', rating: 4 }).expect(201)
    expect(post.body.published).toBe(true)
    expect(post.body.review.course).toBe('NUL student')
    const { body } = await request(app).get('/api/reviews').expect(200)
    expect(body.count).toBe(5)
    expect(body.reviews[0]).toMatchObject({ name: 'Lerato', rating: 4 })
  })

  it('validates like the frontend does', async () => {
    const app = build()
    const r1 = await request(app).post('/api/reviews').send({ name: '', quote: 'long enough review text here' }).expect(400)
    expect(r1.body.fields.name).toBe('Please add your name.')
    const r2 = await request(app).post('/api/reviews').send({ name: 'A', quote: 'too short' }).expect(400)
    expect(r2.body.fields.quote).toMatch(/15 characters/)
    await request(app).post('/api/reviews').send({ name: 'A', quote: 'long enough review text here', rating: 9 }).expect(400)
  })

  it('moderation mode keeps reviews pending until approved by admin', async () => {
    const app = build({ reviewsAutoApprove: false })
    const post = await request(app).post('/api/reviews').send({ name: 'Thabo', quote: 'Great shelf, saved me a lot of money.' }).expect(201)
    expect(post.body.published).toBe(false)
    expect((await request(app).get('/api/reviews')).body.count).toBe(4)
    await request(app).patch(`/api/admin/reviews/${post.body.review.id}`).set('Authorization', `Bearer ${ADMIN}`).send({ status: 'approved' }).expect(200)
    expect((await request(app).get('/api/reviews')).body.count).toBe(5)
  })

  it('honeypot submissions are dropped silently', async () => {
    const app = build()
    await request(app).post('/api/reviews').send({ name: 'Bot', quote: 'buy cheap pills now now now', website: 'http://spam' }).expect(201)
    expect((await request(app).get('/api/reviews')).body.count).toBe(4)
  })
})

describe('contact', () => {
  it('stores the message and emails the inbox with reply-to set', async () => {
    const app = build()
    const res = await request(app).post('/api/contact').send({ name: 'Nthati Kolo', email: 'Nthati@NUL.ls', topic: 'Hall plan', message: 'Do you offer a hall discount for 6 people?' }).expect(201)
    expect(res.body.message).toMatch(/Thanks, Nthati/)
    const row = db.prepare('SELECT * FROM contact_messages').get() as { email: string; topic: string }
    expect(row).toMatchObject({ email: 'nthati@nul.ls', topic: 'Hall plan' })
    expect(sent).toHaveLength(1)
    expect(sent[0]).toMatchObject({ to: 'inbox@example.com', replyTo: 'nthati@nul.ls' })
  })

  it('returns per-field errors with the frontend wording', async () => {
    const { body } = await request(build()).post('/api/contact').send({ name: 'A', email: 'nope', message: 'short' }).expect(400)
    expect(body.fields).toEqual({
      name: 'Enter your name (2+ characters).',
      email: 'Enter a valid email address.',
      message: 'Tell us a little more (10+ characters).',
    })
    expect(sent).toHaveLength(0)
  })

  it('rejects unknown topics and malformed JSON', async () => {
    const app = build()
    await request(app).post('/api/contact').send({ name: 'Ann', email: 'a@b.co', topic: 'Hax', message: 'a long enough message' }).expect(400)
    await request(app).post('/api/contact').set('Content-Type', 'application/json').send('{bad').expect(400)
  })

  it('email header injection attempts cannot add headers', async () => {
    await request(build()).post('/api/contact').send({ name: 'Eve\r\nBcc: x@evil.com', email: 'e@e.co', message: 'hello there, this is a test' }).expect(201)
    // the line break collapses to a space in the stored name, and the notification subject is a single line
    const row = db.prepare('SELECT name FROM contact_messages').get() as { name: string }
    expect(row.name).toBe('Eve Bcc: x@evil.com')
    expect(sent[0]!.subject).not.toMatch(/[\r\n]/)
  })
})

describe('newsletter (double opt-in)', () => {
  const tokenFromMail = () => /token=([a-f0-9]{48})/.exec(sent.at(-1)!.text)![1]!

  it('subscribe -> confirm -> unsubscribe', async () => {
    const app = build()
    await request(app).post('/api/newsletter/subscribe').send({ email: 'Mpho@nul.ls' }).expect(202)
    expect(sent).toHaveLength(1)
    expect(db.prepare('SELECT status FROM subscribers').get()).toEqual({ status: 'pending' })

    const confirm = await request(app).get(`/api/newsletter/confirm?token=${tokenFromMail()}`).expect(200)
    expect(confirm.text).toMatch(/subscribed/)
    expect(db.prepare('SELECT status FROM subscribers').get()).toEqual({ status: 'confirmed' })

    const unsubToken = (db.prepare('SELECT unsub_token t FROM subscribers').get() as { t: string }).t
    await request(app).get(`/api/newsletter/unsubscribe?token=${unsubToken}`).expect(200)
    expect(db.prepare('SELECT status FROM subscribers').get()).toEqual({ status: 'unsubscribed' })
  })

  it('gives identical responses for new and already-confirmed addresses (no enumeration)', async () => {
    const app = build()
    const a = await request(app).post('/api/newsletter/subscribe').send({ email: 'x@nul.ls' })
    await request(app).get(`/api/newsletter/confirm?token=${tokenFromMail()}`)
    const before = sent.length
    const b = await request(app).post('/api/newsletter/subscribe').send({ email: 'x@nul.ls' })
    expect(b.status).toBe(a.status)
    expect(b.body).toEqual(a.body)
    expect(sent.length).toBe(before) // already confirmed -> no extra email
    expect(db.prepare('SELECT COUNT(*) n FROM subscribers').get()).toEqual({ n: 1 })
  })

  it('rejects bad emails and bad tokens', async () => {
    const app = build()
    const bad = await request(app).post('/api/newsletter/subscribe').send({ email: 'nope' }).expect(400)
    expect(bad.body.fields.email).toBe('Enter a valid email address.')
    await request(app).get('/api/newsletter/confirm?token=abc').expect(400)
    await request(app).get(`/api/newsletter/confirm?token=${'0'.repeat(48)}`).expect(404)
  })
})

describe('signup', () => {
  it('creates a student, sends one welcome email with a confirm link', async () => {
    const app = build()
    const res = await request(app).post('/api/signup').send({ name: 'Palesa Mokoena', email: 'palesa@nul.ls', skinType: 'Oily', concerns: 'Acne' }).expect(201)
    expect(res.body.message).toMatch(/Welcome, Palesa/)
    expect(db.prepare('SELECT name, skin_type, concerns FROM students').get()).toEqual({ name: 'Palesa Mokoena', skin_type: 'Oily', concerns: 'Acne' })
    expect(sent).toHaveLength(1)
    expect(sent[0]!.text).toMatch(/\/api\/newsletter\/confirm\?token=/)
  })

  it('signing up twice updates instead of failing, and keeps old optional data', async () => {
    const app = build()
    await request(app).post('/api/signup').send({ name: 'Palesa', email: 'palesa@nul.ls', skinType: 'Dry', concerns: 'Eczema' }).expect(201)
    await request(app).post('/api/signup').send({ name: 'Palesa M', email: 'PALESA@nul.ls', skinType: '' }).expect(201)
    expect(db.prepare('SELECT COUNT(*) n FROM students').get()).toEqual({ n: 1 })
    expect(db.prepare('SELECT name, skin_type, concerns FROM students').get()).toEqual({ name: 'Palesa M', skin_type: 'Dry', concerns: 'Eczema' })
  })

  it('validates', async () => {
    const app = build()
    const { body } = await request(app).post('/api/signup').send({ name: '', email: 'bad', skinType: 'Purple' }).expect(400)
    expect(Object.keys(body.fields).sort()).toEqual(['email', 'name', 'skinType'])
  })
})

describe('admin', () => {
  const auth = (r: request.Test) => r.set('Authorization', `Bearer ${ADMIN}`)

  it('is locked without the token', async () => {
    const app = build()
    await request(app).get('/api/admin/summary').expect(401)
    await request(app).get('/api/admin/summary').set('Authorization', 'Bearer wrong').expect(401)
    await auth(request(app).get('/api/admin/summary')).expect(200)
  })

  it('is disabled entirely when ADMIN_TOKEN is empty', async () => {
    const app = build({ adminToken: '' })
    await request(app).get('/api/admin/summary').set('Authorization', 'Bearer ').expect(503)
  })

  it('lists submissions, never leaks subscriber tokens, exports CSV safely', async () => {
    const app = build()
    await request(app).post('/api/contact').send({ name: '=HYPERLINK("evil")', email: 'a@b.co', message: 'this is a long enough message' })
    await request(app).post('/api/newsletter/subscribe').send({ email: 'sub@nul.ls' })

    const contacts = await auth(request(app).get('/api/admin/contacts')).expect(200)
    expect(contacts.body.total).toBe(1)
    const subs = await auth(request(app).get('/api/admin/subscribers')).expect(200)
    expect(JSON.stringify(subs.body)).not.toMatch(/token/)

    const csv = await auth(request(app).get('/api/admin/contacts?format=csv')).expect(200)
    expect(csv.headers['content-type']).toMatch(/csv/)
    expect(csv.text).toContain(`"'=HYPERLINK(""evil"")"`) // formula neutralised + quotes escaped

    await auth(request(app).patch('/api/admin/contacts/1').send({ handled: true })).expect(200)
    expect((await auth(request(app).get('/api/admin/summary'))).body.contactMessages.unhandled).toBe(0)
  })

  it('can delete a review', async () => {
    const app = build()
    await auth(request(app).delete('/api/admin/reviews/1')).expect(204)
    expect((await request(app).get('/api/reviews')).body.count).toBe(3)
    await auth(request(app).delete('/api/admin/reviews/999')).expect(404)
  })
})

describe('rate limiting', () => {
  it('throttles form posts when enabled', async () => {
    const mailer: Mailer = { async send() {} }
    const app = createApp({ db, config: { ...baseConfig, adminToken: ADMIN }, mailer, rateLimit: true })
    let last = 0
    for (let i = 0; i < 20; i++) last = (await request(app).post('/api/newsletter/subscribe').send({ email: `u${i}@nul.ls` })).status
    expect(last).toBe(429)
  })
})

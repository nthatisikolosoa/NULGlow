/**
 * Runs apps-script/Code.gs in Node against in-memory fakes of the Google services it uses
 * (SpreadsheetApp, MailApp, CacheService, LockService, ContentService, HtmlService, ScriptApp, Utilities).
 * The Sheet fake mimics one important Google behaviour: a value starting with "=" written to a cell that is
 * NOT formatted as plain text gets evaluated as a formula. We mark such cells so tests can assert none exist.
 */
import { randomUUID } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import vm from 'node:vm'

export const FORMULA = '#EVALUATED_AS_FORMULA'
const SCRIPT_URL = 'https://script.google.com/macros/s/TEST/exec'

export class FakeSheet {
  rows: unknown[][] = []
  formats = new Map<string, string>()
  frozen = 0
  constructor(public name: string) {}
  appendRow(vals: unknown[]) { this.rows.push([...vals]) }
  setFrozenRows(n: number) { this.frozen = n }
  getLastRow() { return this.rows.length }
  getDataRange() { return { getValues: () => this.rows.map((r) => [...r]) } }
  getRange(row: number, col: number, nRows = 1, nCols = 1) {
    const self = this
    const range = {
      setFontWeight: () => range,
      setNumberFormat(f: string) {
        for (let r = 0; r < nRows; r++) for (let c = 0; c < nCols; c++) self.formats.set(`${row + r},${col + c}`, f)
        return range
      },
      setValues(vals: unknown[][]) {
        for (let r = 0; r < nRows; r++) {
          const target = (self.rows[row - 1 + r] ??= [])
          for (let c = 0; c < nCols; c++) {
            let v = vals[r]![c]
            if (typeof v === 'string' && v.startsWith('=') && self.formats.get(`${row + r},${col + c}`) !== '@') v = FORMULA
            target[col - 1 + c] = v
          }
        }
        return range
      },
    }
    return range
  }
}

export interface Mail { to: string; subject: string; body: string; replyTo?: string }

export function createEnv(opts: { config?: Record<string, unknown> } = {}) {
  const sheets = new Map<string, FakeSheet>()
  const sent: Mail[] = []
  const cache = new Map<string, string>()
  const env = { quota: 100, failMail: false }

  const sandbox: Record<string, unknown> = {
    console,
    SpreadsheetApp: {
      getActiveSpreadsheet: () => ({
        getSheetByName: (n: string) => sheets.get(n) ?? null,
        insertSheet: (n: string) => { const s = new FakeSheet(n); sheets.set(n, s); return s },
      }),
    },
    MailApp: {
      sendEmail: (m: Mail) => { if (env.failMail) throw new Error('Service invoked too many times'); sent.push(m); env.quota-- },
      getRemainingDailyQuota: () => env.quota,
    },
    CacheService: { getScriptCache: () => ({ get: (k: string) => cache.get(k) ?? null, put: (k: string, v: string) => void cache.set(k, v) }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    ContentService: {
      MimeType: { JSON: 'application/json' },
      createTextOutput: (s: string) => ({ s, setMimeType() { return this }, getContent() { return this.s } }),
    },
    HtmlService: { createHtmlOutput: (html: string) => ({ html, setTitle(t: string) { this.title = t; return this }, title: '' }) },
    ScriptApp: { getService: () => ({ getUrl: () => SCRIPT_URL }) },
    Utilities: { getUuid: () => randomUUID() },
  }
  const ctx = vm.createContext(sandbox)
  vm.runInContext(readFileSync(fileURLToPath(new URL('../apps-script/Code.gs', import.meta.url)), 'utf8'), ctx, { filename: 'Code.gs' })
  Object.assign((ctx as { CONFIG: Record<string, unknown> }).CONFIG, { SITE_URL: 'https://site.example/repo/', CONTACT_INBOX: 'inbox@example.com' }, opts.config)

  const g = ctx as unknown as { doPost(e: unknown): { getContent(): string }; doGet(e: unknown): { getContent?(): string; html?: string; title?: string }; CONFIG: Record<string, unknown> }
  return {
    sheets, sent, env, config: g.CONFIG, cache,
    post: (body: unknown) => JSON.parse(g.doPost({ postData: { contents: typeof body === 'string' ? body : JSON.stringify(body) } }).getContent()) as Record<string, any>,
    get: (parameter: Record<string, string>) => g.doGet({ parameter }),
    getJson: (parameter: Record<string, string>) => JSON.parse(g.doGet({ parameter }).getContent!()) as Record<string, any>,
    sheet: (n: string) => sheets.get(n),
    /** Every cell in every sheet, to assert nothing was evaluated as a formula. */
    allCells: () => [...sheets.values()].flatMap((s) => s.rows.flat()),
  }
}

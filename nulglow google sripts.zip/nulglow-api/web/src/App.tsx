import { BackToTop, Footer, Header, StickyCta } from './components/Layout'
import { Brands, Contact, Discounts, Home, Recommendations, Story } from './pages/Pages'
import { useRoute } from './lib/router'

/** App shell: skip link, header, routed <main>, fat footer, back-to-top. */
export default function App() {
  const path = useRoute()
  const Page = { '/': Home, '/recommendations': Recommendations, '/brands': Brands, '/discounts': Discounts, '/story': Story, '/contact': Contact }[path] ?? Home

  return (
    <div className="min-h-screen bg-blush pb-24">
      <a href="#main" onClick={(e) => { e.preventDefault(); document.getElementById('main')?.focus() }} className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-white focus:px-5 focus:py-3 focus:font-semibold">
        Skip to content
      </a>
      <Header path={path} />
      <main id="main" tabIndex={-1} className="outline-none">
        <Page />
      </main>
      <Footer />
      <BackToTop />
      <StickyCta path={path} />
    </div>
  )
}

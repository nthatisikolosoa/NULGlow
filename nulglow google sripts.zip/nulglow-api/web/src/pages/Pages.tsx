import HeroSlideshow from '../components/HeroSlideshow'
import consultPhoto from '../assets/deals/pic4.jpg'
import ctaPhoto from '../assets/deals/pic5.jpg'
import storyPhoto from '../assets/our-story.png'
import HeroCanvas from '../components/HeroCanvas'
import { BRANDS, SHELF } from '../lib/data'
import { ContactForm, ShelfCard, Deals, Pricing, ProductShelf, ReviewsCarousel, RoutineBuilder, Stats } from '../components/Sections'
import { Container, PageShell, PageTitle, Reveal, SectionHead } from '../components/ui'

/* ------------------------------ HOME ------------------------------ */
const pill = 'inline-flex min-h-11 items-center justify-center rounded-full bg-white px-8 text-sm font-semibold text-mauve shadow-sm transition hover:-translate-y-0.5 hover:bg-blush'
const solid = 'inline-flex min-h-11 items-center justify-center rounded-full bg-mauve px-8 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-plum'

export function Home() {
  return (
    <div>
      {/* Full-bleed photo hero, centred serif headline */}
      <section aria-labelledby="hero-title" className="relative isolate flex min-h-[80vh] items-center justify-center overflow-hidden">
        <HeroSlideshow />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-plum/60 via-mauve/50 to-plum/70" aria-hidden="true" />
        <div className="mx-auto max-w-3xl px-5 py-24 text-center text-white">
          <p className="mb-5 text-xs font-semibold uppercase tracking-[0.25em] text-white/90">For university students</p>
          <h1 id="hero-title" className="font-serif text-5xl font-semibold leading-[1.08] sm:text-7xl">
            Clear skin that begins <span className="italic">on a student budget.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-lg text-lg text-white/90">Built for every skin type, every skin tone and every skin concern. Products from the shops you already walk past. No hype. No markup.</p>
          <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
            <a href="#/recommendations" className={pill}>Build my routine</a>
            <a href="#/discounts" onClick={(e) => { e.preventDefault(); window.location.hash = '/discounts' }} className="inline-flex min-h-11 items-center justify-center rounded-full border border-white/80 px-8 text-sm font-semibold text-white transition hover:bg-white/15">See discounts</a>
          </div>
        </div>
      </section>

      {/* White band: how it works */}
      <section aria-labelledby="how" className="bg-white py-24">
        <Container>
          <h2 id="how" className="text-center font-serif text-4xl font-semibold text-plum sm:text-5xl">How it works</h2>
          <ol className="mt-14 grid gap-10 md:grid-cols-3">
            {[
              ['Tell us your skin', 'Oily, dry, combination or sensitive. Pick one and set your monthly budget.'],
              ['Get your shelf', 'We match each step to real products on sale at local stores.'],
              ['Shop and save', 'Use student codes at the till. Track what works in your first eight weeks.'],
            ].map(([t, d], i) => (
              <Reveal as="li" key={t} delay={i * 100} className="text-center">
                <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-petal font-serif text-2xl text-mauve">0{i + 1}</span>
                <h3 className="mt-5 font-serif text-xl font-semibold text-plum">{t}</h3>
                <p className="mx-auto mt-2 max-w-xs text-ink-soft">{d}</p>
              </Reveal>
            ))}
          </ol>
          <div className="mt-12 text-center">
            <a href="#/recommendations" className={solid}>Start my routine</a>
          </div>
        </Container>
      </section>

      {/* Inclusivity band */}
      <section aria-labelledby="inclusive" className="bg-blush py-24">
        <Container className="text-center">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.22em] text-mauve">Skin care for everyone</p>
          <h2 id="inclusive" className="mx-auto max-w-3xl font-serif text-4xl font-semibold text-plum sm:text-5xl">
            Every skin type. Every skin tone. <span className="italic">Every skin concern.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-ink-soft">Your skin is not a problem to fix. Whatever you are working with, you deserve a routine that fits it and a price that fits you.</p>
          <ul className="mx-auto mt-10 flex max-w-4xl flex-wrap justify-center gap-3" aria-label="Skin types and concerns we cover">
            {['Oily', 'Dry', 'Combination', 'Sensitive', 'Acne and breakouts', 'Hyperpigmentation', 'Dark spots and scarring', 'Eczema', 'Rosacea', 'Vitiligo', 'Keloids', 'Razor bumps', 'Dullness', 'Dark circles', 'Texture'].map((t) => (
              <li key={t} className="rounded-full bg-white px-5 py-2 text-sm font-semibold text-mauve shadow-sm">{t}</li>
            ))}
          </ul>
          <p className="mx-auto mt-8 max-w-xl text-sm text-ink-soft">Don't see yours? Ask us at a free Wednesday consult or send a message.</p>
        </Container>
      </section>

      {/* Dusty-rose band: text left, photo right */}
      <section aria-labelledby="consult" className="bg-dusty py-24">
        <Container className="grid items-center gap-12 md:grid-cols-2">
          <Reveal>
            <h2 id="consult" className="font-serif text-4xl font-semibold leading-tight text-plum sm:text-5xl">
              Free skin consults<br />every Wednesday
            </h2>
            <p className="mt-5 text-xl font-medium text-plum">Ten minutes with a pharmacist. Walk in, no booking needed.</p>
            <p className="mt-2 text-plum/80">Mzalas Complex Pharmacy, 12:00–16:00.</p>
            <a href="#/contact" className={`${pill} mt-8`}>Find us</a>
          </Reveal>
          <Reveal delay={120}>
            <img src={consultPhoto} alt="Hands raising a peach product box against a soft blue sky" loading="lazy" className="mx-auto aspect-[4/5] w-full max-w-sm object-cover object-top" />
          </Reveal>
        </Container>
      </section>

      {/* Pink band: reviews + call to action */}
      <section aria-labelledby="home-reviews" className="bg-petal py-24">
        <Container className="grid items-start gap-14 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <h2 id="home-reviews" className="mb-8 font-serif text-3xl font-semibold text-plum sm:text-4xl">Loved by students</h2>
            <ReviewsCarousel />
          </div>
          <Reveal className="text-center lg:pt-14 lg:text-left">
            <h2 className="font-serif text-3xl font-semibold text-plum sm:text-4xl">Ready to glow like never before?</h2>
            <p className="mt-4 text-ink-soft">Join students at NUL who swapped guesswork for a simple routine they can afford.</p>
            <img src={ctaPhoto} alt="Hands holding a bouquet of pastel skincare products" loading="lazy" className="mx-auto mt-6 aspect-square w-48 object-cover lg:mx-0" />
            <a href="#/recommendations" className={`${solid} mt-6`}>Build my routine</a>
          </Reveal>
        </Container>
      </section>
    </div>
  )
}

/* ------------------------- RECOMMENDATIONS ------------------------- */
export function Recommendations() {
  return (
    <PageShell>
      <PageTitle eyebrow="Recommendations" title="Your skin," accent="your shelf." intro="Choose a skin type and a budget. Every skin type and concern is welcome. Every product below is stocked at a partner store near campus." />
      <Container>
        <RoutineBuilder />
        <section aria-labelledby="shelf" className="pt-24">
          <SectionHead id="shelf" eyebrow="Suggested products" title="Pick a step," accent="build your shelf." intro="Our favourites from Portia M, Garnier and CeraVe, with prices in Maloti." />
          <ProductShelf />
        </section>
        <Reveal className="glass mt-10 p-8">
          <h2 className="text-xl font-bold">Pharmacist <span className="accent-serif">rules of thumb</span></h2>
          <ul className="mt-4 grid gap-3 text-ink-soft sm:grid-cols-3">
            <li><strong className="text-plum">Introduce one product at a time.</strong> Wait a week before adding the next.</li>
            <li><strong className="text-plum">SPF every morning.</strong> It does more than any serum.</li>
            <li><strong className="text-plum">Patch test.</strong> Dab behind your ear for 24 hours first.</li>
          </ul>
        </Reveal>
      </Container>
    </PageShell>
  )
}

/* ---------------------------- DISCOUNTS ---------------------------- */
export function Discounts() {
  return (
    <PageShell>
      <PageTitle eyebrow="Discounts" title="Student prices," accent="verified." intro="Tap a code to copy it. Show your student ID in store." />
      <Container>
        <Deals />
      </Container>
      <section aria-labelledby="plans" className="py-24">
        <Container>
          <SectionHead id="plans" eyebrow="Plans" title="Pay less," accent="save more." intro="Free is enough to start. Glow unlocks members-only codes." />
          <Pricing />
        </Container>
      </section>
    </PageShell>
  )
}

/* ---------------------------- OUR STORY ---------------------------- */
export function Story() {
  return (
    <PageShell>
      <PageTitle eyebrow="Our story" title="Skincare shouldn't need" accent="a trust fund." intro="NULGlow exists because good skin advice was either expensive or buried in hype." />
      <Container>
        <div className="mx-auto grid max-w-4xl items-center gap-10 md:grid-cols-[minmax(0,22rem)_1fr]">
          <Reveal>
            <img src={storyPhoto} alt="Portrait of a NULGlow team member with long burgundy hair, seated in a bright marble-walled salon" width={900} height={1600} loading="lazy" className="aspect-[3/4] w-full rounded-[2rem] bg-rose/40 object-cover object-top shadow-[0_24px_60px_rgba(157,78,124,0.28)]" />
          </Reveal>
          <Reveal delay={120}>
            <p className="mb-3 text-xs font-semibold uppercase tracking-[0.22em] text-mauve">The face behind the shelf</p>
            <h2 className="text-3xl font-bold sm:text-4xl">Beauty is <span className="accent-serif">personal.</span></h2>
            <p className="mt-4 text-lg text-ink-soft">NULGlow started from a simple belief: looking after your skin should feel good, not guilty. Every recommendation is one we would put in our own basket.</p>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ['Honest', 'We list what works and say so when it is a skip. No sponsored placements.'],
            ['Local', 'Every recommendation is on a shelf within ten minutes of campus.'],
            ['Affordable', 'If a M75 product does the job, we will never send you to a M700 one.'],
            ['Inclusive', 'All skin types, tones and concerns, from acne and eczema to hyperpigmentation and vitiligo.'],
          ].map(([t, d], i) => (
            <Reveal key={t} delay={i * 100} className="glass glass-hover p-8">
              <h2 className="text-xl font-bold"><span className="accent-serif">{t}</span></h2>
              <p className="mt-2 text-ink-soft">{d}</p>
            </Reveal>
          ))}
        </div>

        <div className="pt-24" />
        <SectionHead eyebrow="Reviews" title="What students" accent="tell us." />
        <ReviewsCarousel />
      </Container>
    </PageShell>
  )
}

/* ----------------------------- CONTACT ----------------------------- */
export function Contact() {
  return (
    <PageShell>
      <PageTitle eyebrow="Contact" title="Ask the" accent="skin pharmacist." intro="Questions about a product, a reaction or a partnership. We read everything." />
      <Container className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <ContactForm />
        <aside className="glass h-fit p-8">
          <h2 className="text-xl font-bold">Drop <span className="accent-serif">by</span></h2>
          <p className="mt-3 text-ink-soft">National University of Lesotho<br />Main Campus, Roma 180<br />29.4517° S, 27.7186° E<br />Mon–Fri, 14:00–17:00</p>
          <p className="mt-5 text-sm text-ink-soft">Free ten-minute skin consults at Mzalas Complex Pharmacy every Wednesday, 12:00–16:00. No booking.</p>
          <p className="mt-5"><a href="mailto:clara.kolosoan@gmail.com" className="font-semibold text-mauve underline">clara.kolosoan@gmail.com</a></p>
        </aside>
      </Container>
    </PageShell>
  )
}

/* ------------------------------ BRANDS ------------------------------ */
export function Brands() {
  return (
    <PageShell>
      <PageTitle eyebrow="Brands" title="Three brands," accent="one honest shelf." intro="We only recommend what you can buy locally. Here is who they are, what they do best, and what they cost in Maloti." />
      <Container>
        <nav aria-label="Jump to brand" className="mb-12 flex flex-wrap justify-center gap-2">
          {BRANDS.map((b) => (
            <a key={b.name} href={`#/brands`} onClick={(e) => { e.preventDefault(); document.getElementById(`brand-${b.name.replace(' ', '-')}`)?.scrollIntoView({ behavior: 'smooth' }) }} className="btn btn-ghost !min-h-10 text-sm">
              {b.name}
            </a>
          ))}
        </nav>
        <div className="space-y-24">
          {BRANDS.map((b) => {
            const items = SHELF.filter((p) => p.brand === b.name)
            const prices = items.map((p) => p.price)
            return (
              <section key={b.name} id={`brand-${b.name.replace(' ', '-')}`} aria-labelledby={`h-${b.name.replace(' ', '-')}`} className="scroll-mt-40">
                <Reveal className="glass mb-8 grid gap-6 p-8 md:grid-cols-[1.4fr_1fr] md:items-center">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-widest text-mauve">{b.best}</p>
                    <h2 id={`h-${b.name.replace(' ', '-')}`} className="mt-2 text-3xl font-extrabold">
                      {b.name} <span className="accent-serif">{b.tagline}</span>
                    </h2>
                    <p className="mt-3 text-ink-soft">{b.about}</p>
                    <a href={b.url} target="_blank" rel="noopener noreferrer" className="mt-4 inline-block font-semibold text-mauve underline">
                      Shop at {b.stockist} (opens in a new tab)
                    </a>
                  </div>
                  <dl className="grid grid-cols-2 gap-4 text-center">
                    <div className="rounded-2xl bg-white/70 p-4">
                      <dt className="text-xs uppercase tracking-widest text-ink-soft">Products</dt>
                      <dd className="mt-1 text-2xl font-extrabold">{items.length}</dd>
                    </div>
                    <div className="rounded-2xl bg-white/70 p-4">
                      <dt className="text-xs uppercase tracking-widest text-ink-soft">Price range</dt>
                      <dd className="mt-1 text-lg font-extrabold">M{Math.round(Math.min(...prices))}–M{Math.round(Math.max(...prices))}</dd>
                    </div>
                  </dl>
                </Reveal>
                <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
                  {items.map((p) => (
                    <ShelfCard key={p.name} p={p} />
                  ))}
                </ul>
              </section>
            )
          })}
        </div>
      </Container>
    </PageShell>
  )
}

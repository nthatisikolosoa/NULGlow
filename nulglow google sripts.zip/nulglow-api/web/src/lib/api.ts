/**
 * How the website talks to its backend. The UI only ever calls `api.*`; which backend answers is chosen at build time:
 *
 *   VITE_FORMS_URL set -> Google Apps Script web app (free, no server; for GitHub Pages)   see apps-script/SETUP.md
 *   otherwise          -> the Node API at VITE_API_URL, or same-origin /api when the Node server hosts this site
 */
import { REVIEWS } from './data'

const FORMS_URL = (import.meta.env.VITE_FORMS_URL as string | undefined) ?? ''
const API_URL = (import.meta.env.VITE_API_URL as string | undefined) ?? ''

/** Thrown for any failure. `fields` maps input name -> message (same wording as the UI's own validation). */
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public fields: Record<string, string> = {},
  ) {
    super(message)
  }
}

export interface Review { name: string; course: string; quote: string; rating: number; id?: number; createdAt?: string }

/** `website` is a hidden honeypot field: real people never fill it in, bots do, and the backend then discards the message. */
interface Honeypot { website?: string }

export interface FormsApi {
  contact(d: { name: string; email: string; topic: string; message: string } & Honeypot): Promise<{ ok: true; message: string }>
  subscribe(email: string, website?: string): Promise<{ ok: true; message: string }>
  signup(d: { name: string; email: string; skinType?: string; concerns?: string } & Honeypot): Promise<{ ok: true; message: string }>
  reviews(): Promise<{ reviews: Review[] }>
  createReview(r: { name: string; course?: string; quote: string; rating: number } & Honeypot): Promise<{ ok: true; published: boolean; review: Review }>
}

const OFFLINE = 'Could not reach the server. Check your connection and try again.'

/* ----------------------------- Node API (REST) ----------------------------- */
async function rest<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response
  try {
    res = await fetch(`${API_URL}/api${path}`, { ...init, headers: { 'Content-Type': 'application/json', ...init?.headers } })
  } catch {
    throw new ApiError(0, OFFLINE)
  }
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new ApiError(res.status, body.error ?? 'Something went wrong.', body.fields)
  return body as T
}
const post = <T>(path: string, data: unknown) => rest<T>(path, { method: 'POST', body: JSON.stringify(data) })

const nodeApi: FormsApi = {
  contact: (d) => post('/contact', d),
  subscribe: (email, website) => post('/newsletter/subscribe', { email, website }),
  signup: (d) => post('/signup', d),
  reviews: () => rest('/reviews'),
  createReview: (r) => post('/reviews', r),
}

/* ------------------------- Google Apps Script (no server) ------------------------- */
/**
 * Apps Script web apps always answer HTTP 200 with {ok:false,...} on errors, and they do not answer CORS preflight
 * requests. So POSTs are sent WITHOUT a Content-Type header (the browser then uses text/plain, a "simple" request that
 * skips preflight) and the JSON is carried in the body. Using application/json here would be blocked by the browser.
 */
async function script<T>(init?: RequestInit, query = ''): Promise<T> {
  let res: Response
  try {
    res = await fetch(FORMS_URL + query, init)
  } catch {
    throw new ApiError(0, OFFLINE)
  }
  const body = await res.json().catch(() => null)
  if (!body) throw new ApiError(res.status || 502, 'Something went wrong. Please try again.')
  if (!body.ok) throw new ApiError(400, body.error ?? 'Something went wrong.', body.fields)
  return body as T
}
const send = <T>(action: string, data: object) => script<T>({ method: 'POST', body: JSON.stringify({ action, ...data }) })

const scriptApi: FormsApi = {
  contact: (d) => send('contact', d),
  subscribe: (email, website) => send('subscribe', { email, website }),
  signup: (d) => send('signup', d),
  // Same order the carousel always had: newest student reviews first, then the four starter reviews.
  reviews: async () => ({ reviews: [...(await script<{ reviews: Review[] }>(undefined, '?action=reviews')).reviews, ...REVIEWS] }),
  createReview: (r) => send('review', r),
}

export const api: FormsApi = FORMS_URL ? scriptApi : nodeApi

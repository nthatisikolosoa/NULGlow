import type { Budget, SkinType } from './data'

export const SKIN_TYPES: readonly SkinType[] = ['Oily', 'Dry', 'Combination', 'Sensitive']
export const BUDGETS: readonly Budget[] = ['Under M300', 'Under M550', 'Under M900']

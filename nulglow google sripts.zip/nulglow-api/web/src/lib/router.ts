import { useEffect, useState } from 'react'

/** Pages of the site. Each maps to a hash route, e.g. #/story */
export const ROUTES = [
  { path: '/', label: 'Home' },
  { path: '/recommendations', label: 'Recommendations' },
  { path: '/brands', label: 'Brands' },
  { path: '/discounts', label: 'Discounts' },
  { path: '/story', label: 'Our Story' },
  { path: '/contact', label: 'Contact' },
] as const

const read = () => window.location.hash.replace(/^#/, '') || '/'

/** Minimal hash router: returns the current path and re-renders on change. */
export function useRoute() {
  const [path, setPath] = useState(read)
  useEffect(() => {
    const onChange = () => {
      setPath(read())
      window.scrollTo({ top: 0, behavior: 'auto' }) // new page starts at top
    }
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])
  return path
}

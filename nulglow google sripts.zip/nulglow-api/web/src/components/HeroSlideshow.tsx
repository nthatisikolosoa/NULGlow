import { useEffect, useState } from 'react'
import hero1 from '../assets/hero/hero1.jpg'
import hero2 from '../assets/hero/hero2.jpg'
import hero3 from '../assets/hero/hero3.jpg'
import hero4 from '../assets/hero/hero4.jpg'

const SLIDES = [
  { src: hero1, pos: '50% 50%', alt: 'Three women with closed eyes resting their heads together against a mauve wall' },
  { src: hero3, pos: '50% 40%', alt: 'Three women of different skin tones with glowing skin, heads touching' },
  { src: hero4, pos: '50% 42%', alt: 'Close portrait of a woman with glossy lips resting her chin on her hands' },
  { src: hero2, pos: '50% 30%', alt: 'Collage of glossy lip and face close-ups' },
]

/** Crossfading photo slideshow used as a hero background. */
export default function HeroSlideshow() {
  const [i, setI] = useState(0)
  const [playing, setPlaying] = useState(true)
  const reduced = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

  useEffect(() => {
    if (!playing || reduced) return
    const t = window.setInterval(() => setI((x) => (x + 1) % SLIDES.length), 5500)
    return () => clearInterval(t)
  }, [playing, reduced])

  return (
    <>
      <div className="absolute inset-0 -z-20" role="group" aria-roledescription="slideshow" aria-label="Skin photography">
        {SLIDES.map((s, idx) => (
          <img
            key={s.src}
            src={s.src}
            alt={idx === i ? s.alt : ''}
            aria-hidden={idx !== i}
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-[1400ms] ease-in-out ${idx === i ? 'opacity-100' : 'opacity-0'} ${idx === i && !reduced ? 'animate-[kenburns_9s_ease-out_both]' : ''}`}
            style={{ objectPosition: s.pos }}
          />
        ))}
      </div>
      <div className="absolute inset-x-0 bottom-5 z-10 flex items-center justify-center gap-1">
        <button type="button" onClick={() => setPlaying(!playing)} aria-label={playing ? 'Pause slideshow' : 'Play slideshow'} className="flex h-11 w-11 items-center justify-center rounded-full text-white hover:bg-white/15">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">{playing ? <path d="M6 4h4v16H6zM14 4h4v16h-4z" /> : <path d="M7 4l13 8-13 8z" />}</svg>
        </button>
        {SLIDES.map((_, idx) => (
          <button key={idx} type="button" onClick={() => setI(idx)} aria-label={`Show photo ${idx + 1}`} aria-current={idx === i} className="flex h-11 w-6 items-center justify-center">
            <span className={`block h-2.5 rounded-full bg-white transition-all ${idx === i ? 'w-7' : 'w-2.5 opacity-50'}`} />
          </button>
        ))}
      </div>
    </>
  )
}

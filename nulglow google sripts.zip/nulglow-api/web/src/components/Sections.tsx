import { useEffect, useRef, useState, type FormEvent } from 'react'
import { BUDGETS, SKIN_TYPES } from '../lib/constants'
import { CONCERNS, DEALS, PLANS, REVIEWS, ROUTINES, SHELF, STATS, type Budget, type ShelfBrand, type ShelfProduct, type ShelfStep, type Review, type SkinType } from '../lib/data'
import deal1 from '../assets/deals/pic1.jpg'
import deal2 from '../assets/deals/pic5.jpg'
import deal3 from '../assets/deals/pic6.jpg'
import deal4 from '../assets/deals/sunscreen.jpg'
import deal5 from '../assets/deals/pic4.jpg'
import deal6 from '../assets/deals/pic3.jpg'
import { api, ApiError } from '../lib/api'
import { Container, Honeypot, honeypot, Reveal, SectionHead } from './ui'

/* ------------------------------------------------------------------ */
/* Stats strip                                                         */
/* ------------------------------------------------------------------ */
export function Stats() {
  return (
    <Container>
      <dl className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {STATS.map((s, i) => (
          <Reveal key={s.label} delay={i * 80} className="glass p-6 text-center">
            <dd className="text-3xl font-extrabold text-mauve sm:text-4xl">{s.value}</dd>
            <dt className="mt-1 text-sm text-ink-soft">{s.label}</dt>
          </Reveal>
        ))}
      </dl>
    </Container>
  )
}

/* ------------------------------------------------------------------ */
/* Deals grid                                                          */
/* ------------------------------------------------------------------ */
const DEAL_IMAGES = [
  { src: deal1, pos: '50% 45%', alt: 'Pink cleanser bottle resting in soap foam and bubbles' },
  { src: deal2, pos: '50% 30%', alt: 'Hands holding a bouquet of pastel creams, serums and cleansers' },
  { src: deal3, pos: '50% 45%', alt: 'A hand holding a lilac serum dropper beside a halved grapefruit' },
  { src: deal4, pos: '50% 20%', alt: 'Hands applying a pink SPF 50 sunscreen lotion, a swatch on the back of the hand' },
  { src: deal5, pos: '50% 30%', alt: 'Hands raising a peach product box against a soft blue sky' },
  { src: deal6, pos: '50% 55%', alt: 'A stack of pink and magenta skincare products on a pink background' },
]

export function Deals({ limit }: { limit?: number }) {
  const [copied, setCopied] = useState<string | null>(null)
  const list = limit ? DEALS.slice(0, limit) : DEALS
  const copy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code)
    } catch {
      /* clipboard may be blocked; still show feedback */
    }
    setCopied(code)
    setTimeout(() => setCopied(null), 1800)
  }
  return (
    <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {list.map((d, i) => (
        <Reveal as="li" key={d.code} delay={(i % 3) * 90}>
          <article className="glass glass-hover flex h-full flex-col overflow-hidden">
            <div className="relative aspect-[4/3] bg-rose/40">
              <img src={DEAL_IMAGES[i % DEAL_IMAGES.length].src} alt={DEAL_IMAGES[i % DEAL_IMAGES.length].alt} loading="lazy" className="h-full w-full object-cover" style={{ objectPosition: DEAL_IMAGES[i % DEAL_IMAGES.length].pos }} />
              <span className="absolute left-4 top-4 rounded-full bg-white/90 px-4 py-1.5 text-sm font-extrabold text-mauve backdrop-blur">{d.off}</span>
            </div>
            <div className="flex flex-1 flex-col p-6">
              <p className="text-xs font-semibold uppercase tracking-widest text-mauve">{d.store}</p>
              <h3 className="mt-2 text-xl font-bold">{d.title}</h3>
              <p className="mt-2 flex-1 text-sm text-ink-soft">{d.detail}</p>
              <div className="mt-5 flex items-center justify-between gap-3">
                <span className="text-xs font-medium text-ink-soft">{d.until}</span>
                <button type="button" onClick={() => copy(d.code)} className="btn btn-ghost !min-h-10 !px-4 font-mono text-xs" aria-live="polite">
                  {copied === d.code ? 'Copied' : d.code}
                </button>
              </div>
            </div>
          </article>
        </Reveal>
      ))}
    </ul>
  )
}

/* ------------------------------------------------------------------ */
/* Routine builder (recommendations)                                   */
/* ------------------------------------------------------------------ */
function Chips<T extends string>({ label, options, value, onChange }: { label: string; options: readonly T[]; value: T; onChange: (v: T) => void }) {
  return (
    <fieldset>
      <legend className="mb-3 text-sm font-bold uppercase tracking-widest text-mauve">{label}</legend>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <label key={o} className="cursor-pointer">
            <input type="radio" name={label} value={o} checked={value === o} onChange={() => onChange(o)} className="peer sr-only" />
            <span className="inline-flex min-h-11 items-center rounded-full border border-white bg-white/50 px-5 text-sm font-semibold text-ink-soft transition peer-checked:border-mauve peer-checked:bg-rose peer-checked:text-plum peer-focus-visible:outline peer-focus-visible:outline-[3px] peer-focus-visible:outline-offset-2 peer-focus-visible:outline-mauve hover:bg-white">
              {o}
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  )
}

export function RoutineBuilder() {
  const [skin, setSkin] = useState<SkinType>('Combination')
  const [budget, setBudget] = useState<Budget>('Under M550')
  const [picked, setPicked] = useState<string[]>([])
  const toggle = (l: string) => setPicked((p) => (p.includes(l) ? p.filter((x) => x !== l) : [...p, l]))
  const chosen = CONCERNS.filter((c) => picked.includes(c.label))
  const steps = ROUTINES[skin][budget]
  const total = steps.reduce((s, x) => s + x.product.price, 0)
  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.4fr)]">
      <Reveal className="glass flex flex-col gap-8 p-7 lg:sticky lg:top-44 lg:self-start">
        <Chips label="Skin type" options={SKIN_TYPES} value={skin} onChange={setSkin} />
        <fieldset>
          <legend className="mb-3 text-sm font-semibold text-ink-soft">Skin concerns (pick any)</legend>
          <div className="flex flex-wrap gap-2">
            {CONCERNS.map((c) => (
              <button key={c.label} type="button" aria-pressed={picked.includes(c.label)} onClick={() => toggle(c.label)} className={`min-h-10 rounded-full px-4 text-sm font-semibold transition ${picked.includes(c.label) ? 'bg-mauve text-white' : 'bg-white/70 text-mauve hover:bg-white'}`}>
                {c.label}
              </button>
            ))}
          </div>
        </fieldset>
        <Chips label="Monthly budget" options={BUDGETS} value={budget} onChange={setBudget} />
        <div className="rounded-2xl bg-white/70 p-5" aria-live="polite">
          <p className="text-xs font-semibold uppercase tracking-widest text-ink-soft">Routine total</p>
          <p className="mt-1 text-4xl font-extrabold text-mauve">M{total.toFixed(2)}</p>
          <p className="mt-1 text-sm text-ink-soft">{steps.length} products from local stores</p>
        </div>
      </Reveal>

      <ol className="space-y-4" aria-label={`${skin} skin routine, ${budget}`}>
        {steps.map((s, i) => (
          <li key={`${skin}-${budget}-${i}`} className="glass animate-[fadeUp_0.5s_both] flex items-center gap-5 p-5" style={{ animationDelay: `${i * 70}ms` }}>
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-rose text-lg font-extrabold text-plum">{i + 1}</span>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold uppercase tracking-widest text-mauve">{s.step}</p>
              <h3 className="font-bold">{s.product.name}</h3>
              <p className="text-sm text-ink-soft">
                {s.product.note} <span className="whitespace-nowrap">· {s.product.store}</span>
              </p>
            </div>
            <p className="text-lg font-extrabold">M{s.product.price.toFixed(2)}</p>
          </li>
        ))}
        <li className="px-2 text-sm text-ink-soft">Every routine is for every skin tone. Sunscreen matters for all of us.</li>
        {chosen.length > 0 && (
          <li className="list-none">
            <section aria-label="For your skin concerns" className="space-y-4">
              {chosen.map((c) => (
                <div key={c.label} className="glass p-5">
                  <h3 className="font-bold">{c.label}</h3>
                  <p className="mt-1 text-sm text-ink-soft">{c.advice}</p>
                  <ul className="mt-3 flex flex-wrap gap-2">
                    {c.picks.map((n) => {
                      const p = SHELF.find((x) => x.name === n)
                      return p ? (
                        <li key={n}>
                          <a href={p.url} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-10 items-center gap-2 rounded-full bg-white/80 px-4 text-sm font-semibold text-mauve hover:bg-white">
                            {p.name} <span className="text-ink-soft">M{p.price.toFixed(0)}</span>
                          </a>
                        </li>
                      ) : null
                    })}
                  </ul>
                  {c.doctor && <p className="mt-3 text-xs font-semibold text-mauve">Ask a pharmacist or doctor about treatment. Our free Wednesday consult is a good start.</p>}
                </div>
              ))}
            </section>
          </li>
        )}
      </ol>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Suggested products: filterable shelf with pictures + prices         */
/* ------------------------------------------------------------------ */
const SHELF_FILTERS = ['All', 'Cleanse', 'Tone', 'Treat', 'Moisturize', 'Protect'] as const

export function ShelfCard({ p }: { p: ShelfProduct }) {
  return (
          <li className="animate-[fadeUp_0.5s_both]">
            <article className="glass glass-hover flex h-full flex-col overflow-hidden">
              <div className="aspect-square bg-white/60 p-4">
                <img src={p.img} alt={p.name} loading="lazy" referrerPolicy="no-referrer" className="h-full w-full object-contain" />
              </div>
              <div className="flex flex-1 flex-col p-5">
                <p className="text-xs font-semibold uppercase tracking-widest text-mauve">
                  {p.step} <span className="text-ink-soft">· {p.brand}</span>
                </p>
                <h3 className="mt-1 font-bold leading-snug">{p.name}</h3>
                <p className="mt-2 flex-1 text-sm text-ink-soft">{p.tip}</p>
                <div className="mt-4 flex items-center justify-between gap-2">
                  <p className="text-xl font-extrabold">M{p.price.toFixed(2)}</p>
                  <a href={p.url} target="_blank" rel="noopener noreferrer" className="btn btn-ghost !min-h-10 !px-4 text-sm" aria-label={`View ${p.name} on ${p.brand === 'Portia M' ? 'Portia M' : 'Clicks'} (opens in a new tab)`}>
                    View
                  </a>
                </div>
              </div>
            </article>
          </li>
  )
}

export function ProductShelf({ limit }: { limit?: number }) {
  const [filter, setFilter] = useState<'All' | ShelfStep>('All')
  const [brand, setBrand] = useState<'All brands' | ShelfBrand>('All brands')
  const items = SHELF.filter((p) => (filter === 'All' || p.step === filter) && (brand === 'All brands' || p.brand === brand)).slice(0, limit)
  return (
    <div>
      <div className="mb-8 flex flex-col items-center gap-6 sm:flex-row sm:flex-wrap sm:justify-center sm:gap-12">
        <Chips label="Routine step" options={SHELF_FILTERS} value={filter} onChange={setFilter} />
        <Chips label="Brand" options={['All brands', 'Portia M', 'Garnier', 'CeraVe'] as const} value={brand} onChange={setBrand} />
      </div>
      <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((p) => (
          <ShelfCard key={p.name} p={p} />
        ))}
      </ul>
      <p className="mt-6 text-center text-sm text-ink-soft">
        Products from{' '}
        <a href="https://portiamss.com/" target="_blank" rel="noopener noreferrer" className="font-semibold text-mauve underline">
          Portia M
        </a>
        ,{' '}
        <a href="https://clicks.co.za/brands/garnier-skincare" target="_blank" rel="noopener noreferrer" className="font-semibold text-mauve underline">
          Garnier
        </a>
        , and{' '}
        <a href="https://clicks.co.za/brands/cerave" target="_blank" rel="noopener noreferrer" className="font-semibold text-mauve underline">
          CeraVe
        </a>{' '}
        at Clicks. Prices may change in store.
      </p>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Reviews carousel                                                    */
/* ------------------------------------------------------------------ */
export function ReviewsCarousel() {
  const [i, setI] = useState(0)
  const [paused, setPaused] = useState(false)
  // Show the starter reviews instantly, then swap in the live list from the API.
  const [reviews, setReviews] = useState<Review[]>(REVIEWS)
  useEffect(() => {
    api.reviews().then((r) => r.reviews.length && setReviews(r.reviews)).catch(() => { /* offline: keep the starter reviews */ })
  }, [])
  const n = reviews.length
  const timer = useRef<number>(0)

  // Auto-advance every 7s unless hovered/focused or reduced-motion is set
  useEffect(() => {
    if (paused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    timer.current = window.setInterval(() => setI((x) => (x + 1) % n), 7000)
    return () => clearInterval(timer.current)
  }, [paused, n])

  /** Returns true if the review is already live, false if it is waiting for approval. Throws on failure. */
  const addReview = async (r: Review, website?: string) => {
    const res = await api.createReview({ ...r, website })
    if (res.published) {
      setReviews((x) => [res.review, ...x])
      setI(0)
    }
    return res.published
  }
  const go = (d: number) => setI((x) => (x + d + n) % n)

  return (
    <section
      aria-roledescription="carousel"
      aria-label="Student reviews"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      className="mx-auto max-w-3xl"
    >
      <div className="overflow-hidden rounded-[var(--radius-card)]">
        <div className="flex transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]" style={{ transform: `translateX(-${i * 100}%)` }} aria-live={paused ? 'polite' : 'off'}>
          {reviews.map((r, idx) => (
            <figure key={`${r.name}-${idx}`} role="group" aria-roledescription="slide" aria-label={`${idx + 1} of ${n}`} aria-hidden={idx !== i} className="glass glass-strong m-0 w-full shrink-0 p-8 sm:p-12" style={{ borderRadius: 'var(--radius-card)' }}>
              <div className="flex gap-1 text-mauve" role="img" aria-label={`${r.rating} out of 5 stars`}>
                {Array.from({ length: 5 }, (_, s) => (
                  <svg key={s} width="20" height="20" viewBox="0 0 24 24" fill={s < r.rating ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
                    <path d="M12 3l2.7 5.8 6.3.7-4.7 4.3 1.3 6.2L12 17l-5.6 3 1.3-6.2L3 9.5l6.3-.7z" />
                  </svg>
                ))}
              </div>
              <blockquote className="mt-5 font-serif text-xl leading-relaxed sm:text-2xl">"{r.quote}"</blockquote>
              <figcaption className="mt-6 flex items-center gap-3">
                <img src={`https://picsum.photos/seed/${r.name.replace(/\W/g, '')}/96/96`} alt="" width={48} height={48} className="h-12 w-12 rounded-full bg-rose object-cover" />
                <span>
                  <span className="block font-bold">{r.name}</span>
                  <span className="text-sm text-ink-soft">{r.course}</span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
      <div className="mt-6 flex items-center justify-center gap-4">
        <button type="button" onClick={() => go(-1)} aria-label="Previous review" className="btn btn-ghost !px-0 h-11 w-11">
          ←
        </button>
        <div className="flex gap-2" role="group" aria-label="Choose review">
          {reviews.map((r, idx) => (
            <button key={`${r.name}-${idx}`} type="button" onClick={() => setI(idx)} aria-label={`Show review ${idx + 1}`} aria-current={idx === i} className="flex h-11 w-6 items-center justify-center">
              <span className={`block h-2.5 rounded-full transition-all ${idx === i ? 'w-7 bg-mauve' : 'w-2.5 bg-mauve/35'}`} />
            </button>
          ))}
        </div>
        <button type="button" onClick={() => go(1)} aria-label="Next review" className="btn btn-ghost !px-0 h-11 w-11">
          →
        </button>
      </div>
      <ReviewForm onAdd={addReview} />
    </section>
  )
}

function ReviewForm({ onAdd }: { onAdd: (r: Review, website?: string) => Promise<boolean> }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [course, setCourse] = useState('')
  const [quote, setQuote] = useState('')
  const [rating, setRating] = useState(5)
  const [err, setErr] = useState('')
  const [thanks, setThanks] = useState<'' | 'live' | 'pending'>('')
  const [busy, setBusy] = useState(false)
  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const trap = honeypot(e)
    if (!name.trim()) return setErr('Please add your name.')
    if (quote.trim().length < 15) return setErr('Tell us a little more (at least 15 characters).')
    if (busy) return
    setBusy(true)
    try {
      const live = await onAdd({ name: name.trim(), course: course.trim() || 'NUL student', quote: quote.trim(), rating }, trap)
      setName(''); setCourse(''); setQuote(''); setRating(5); setErr(''); setOpen(false); setThanks(live ? 'live' : 'pending')
    } catch (e) {
      const fe = e instanceof ApiError ? Object.values(e.fields)[0] : undefined
      setErr(fe ?? (e as Error).message)
    } finally {
      setBusy(false)
    }
  }
  const field = 'mt-1 min-h-11 w-full rounded-2xl border border-white bg-white/80 px-4 text-sm'
  return (
    <div className="mt-10 text-center">
      {thanks && <p role="status" className="mb-4 font-semibold text-mauve">{thanks === 'live' ? 'Thanks! Your review is now first in the carousel.' : 'Thanks! Your review will appear once it has been approved.'}</p>}
      {!open && (
        <button type="button" onClick={() => { setOpen(true); setThanks('') }} aria-expanded={open} className="btn btn-primary">
          Write a review
        </button>
      )}
      {open && (
        <form onSubmit={submit} noValidate className="glass relative mx-auto space-y-4 p-6 text-left sm:p-8" aria-label="Write a review">
          <Honeypot />
          <h3 className="text-xl font-bold">Share your <span className="accent-serif">experience</span></h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block text-sm font-semibold">Name
              <input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" className={field} />
            </label>
            <label className="block text-sm font-semibold">Course and year (optional)
              <input value={course} onChange={(e) => setCourse(e.target.value)} placeholder="Nursing, Year 2" className={field} />
            </label>
          </div>
          <fieldset>
            <legend className="text-sm font-semibold">Rating</legend>
            <div className="mt-1 flex gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} type="button" onClick={() => setRating(n)} aria-label={`${n} star${n > 1 ? 's' : ''}`} aria-pressed={n === rating} className="flex h-11 w-11 items-center justify-center text-mauve">
                  <svg width="26" height="26" viewBox="0 0 24 24" fill={n <= rating ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="M12 3l2.7 5.8 6.3.7-4.7 4.3 1.3 6.2L12 17l-5.6 3 1.3-6.2L3 9.5l6.3-.7z" /></svg>
                </button>
              ))}
            </div>
          </fieldset>
          <label className="block text-sm font-semibold">Your review
            <textarea value={quote} onChange={(e) => setQuote(e.target.value)} rows={4} maxLength={300} className={`${field} py-3`} />
          </label>
          {err && <p role="alert" className="text-sm font-semibold text-mauve">{err}</p>}
          <div className="flex gap-2">
            <button type="submit" disabled={busy} className="btn btn-primary">{busy ? 'Posting…' : 'Post review'}</button>
            <button type="button" onClick={() => setOpen(false)} className="btn btn-ghost">Cancel</button>
          </div>
        </form>
      )}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Pricing table                                                       */
/* ------------------------------------------------------------------ */
export function Pricing() {
  return (
    <div className="grid items-stretch gap-6 lg:grid-cols-3">
      {PLANS.map((p, i) => (
        <Reveal key={p.name} delay={i * 100} className="h-full">
          <article className={`glass flex h-full flex-col p-8 ${p.featured ? 'glass-strong ring-2 ring-mauve lg:-translate-y-3' : ''}`}>
            {p.featured && <span className="mb-3 w-fit rounded-full bg-mauve px-3 py-1 text-xs font-bold uppercase tracking-widest text-white">Most popular</span>}
            <h3 className="text-xl font-bold">{p.name}</h3>
            <p className="mt-1 text-sm text-ink-soft">{p.blurb}</p>
            <p className="mt-6 flex items-baseline gap-1">
              <span className="text-5xl font-extrabold">M{p.price}</span>
              <span className="text-ink-soft">/month</span>
            </p>
            <ul className="mt-6 flex-1 space-y-3 text-sm">
              {p.features.map((f) => (
                <li key={f} className="flex gap-3">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#9d4e7c" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0" aria-hidden="true">
                    <path d="M5 12l5 5 9-10" />
                  </svg>
                  {f}
                </li>
              ))}
            </ul>
            <a href="#/contact" className={`btn mt-8 ${p.featured ? 'btn-primary' : 'btn-ghost'}`}>
              {p.cta}
            </a>
          </article>
        </Reveal>
      ))}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Contact form with validation                                        */
/* ------------------------------------------------------------------ */
type Errors = Partial<Record<'name' | 'email' | 'message', string>>

export function ContactForm() {
  const [vals, setVals] = useState({ name: '', email: '', topic: 'Routine help', message: '' })
  const [errors, setErrors] = useState<Errors>({})
  const [sent, setSent] = useState(false)

  const validate = (v = vals): Errors => {
    const e: Errors = {}
    if (v.name.trim().length < 2) e.name = 'Enter your name (2+ characters).'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) e.email = 'Enter a valid email address.'
    if (v.message.trim().length < 10) e.message = 'Tell us a little more (10+ characters).'
    return e
  }
  const set = (k: keyof typeof vals) => (ev: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const next = { ...vals, [k]: ev.target.value }
    setVals(next)
    if (Object.keys(errors).length) setErrors(validate(next)) // live-clear errors once shown
  }
  const [busy, setBusy] = useState(false)
  const submit = async (ev: FormEvent) => {
    ev.preventDefault()
    const trap = honeypot(ev)
    if (busy) return
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) return void document.getElementById(`c-${Object.keys(e)[0]}`)?.focus()
    setBusy(true)
    try {
      await api.contact({ ...vals, website: trap })
      setSent(true)
    } catch (err) {
      // Show the server's per-field messages if it sent any, otherwise a general message under the textarea.
      const fields = err instanceof ApiError && Object.keys(err.fields).length ? err.fields : { message: (err as Error).message }
      setErrors(fields as Errors)
      document.getElementById(`c-${Object.keys(fields)[0]}`)?.focus()
    } finally {
      setBusy(false)
    }
  }

  if (sent)
    return (
      <div role="status" className="glass glass-strong p-10 text-center">
        <p className="text-2xl font-bold">
          Thanks, {vals.name.split(' ')[0]}. <span className="accent-serif">Message sent.</span>
        </p>
        <p className="mt-3 text-ink-soft">We reply within two working days.</p>
        <button type="button" className="btn btn-ghost mt-6" onClick={() => { setSent(false); setVals({ name: '', email: '', topic: 'Routine help', message: '' }) }}>
          Send another
        </button>
      </div>
    )

  const field = 'mt-2 w-full rounded-2xl border bg-white/70 px-4 py-3 text-base placeholder:text-ink-soft/70'
  const err = (k: keyof Errors) => (errors[k] ? 'border-mauve' : 'border-white')
  return (
    <form onSubmit={submit} noValidate className="glass glass-strong relative space-y-5 p-7 sm:p-10" aria-label="Contact form">
      <Honeypot />
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="c-name" className="text-sm font-semibold">Name</label>
          <input id="c-name" value={vals.name} onChange={set('name')} autoComplete="name" aria-invalid={!!errors.name} aria-describedby={errors.name ? 'e-name' : undefined} className={`${field} ${err('name')}`} />
          {errors.name && <p id="e-name" role="alert" className="mt-1 text-sm font-semibold text-mauve">{errors.name}</p>}
        </div>
        <div>
          <label htmlFor="c-email" className="text-sm font-semibold">Email</label>
          <input id="c-email" type="email" value={vals.email} onChange={set('email')} autoComplete="email" aria-invalid={!!errors.email} aria-describedby={errors.email ? 'e-email' : undefined} className={`${field} ${err('email')}`} />
          {errors.email && <p id="e-email" role="alert" className="mt-1 text-sm font-semibold text-mauve">{errors.email}</p>}
        </div>
      </div>
      <div>
        <label htmlFor="c-topic" className="text-sm font-semibold">Topic</label>
        <select id="c-topic" value={vals.topic} onChange={set('topic')} className={`${field} border-white`}>
          <option>Routine help</option>
          <option>Store partnership</option>
          <option>Hall plan</option>
          <option>Something else</option>
        </select>
      </div>
      <div>
        <label htmlFor="c-message" className="text-sm font-semibold">Message</label>
        <textarea id="c-message" rows={5} value={vals.message} onChange={set('message')} aria-invalid={!!errors.message} aria-describedby={errors.message ? 'e-message' : undefined} className={`${field} ${err('message')}`} />
        {errors.message && <p id="e-message" role="alert" className="mt-1 text-sm font-semibold text-mauve">{errors.message}</p>}
      </div>
      <button type="submit" disabled={busy} className="btn btn-primary w-full sm:w-auto">{busy ? 'Sending…' : 'Send message'}</button>
    </form>
  )
}

export { SectionHead }

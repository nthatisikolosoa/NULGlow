import { useEffect, useState, type FormEvent } from 'react'
import { api, ApiError } from '../lib/api'
import { ROUTES } from '../lib/router'
import { SKIN_TYPES } from '../lib/constants'
import { Honeypot, honeypot } from './ui'

/* ---------- Icons (inline SVG, decorative unless labelled by parent) ---------- */
const Svg = ({ children }: { children: React.ReactNode }) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {children}
  </svg>
)
export const Icons = {
  instagram: (
    <Svg>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="0.6" fill="currentColor" />
    </Svg>
  ),
  tiktok: (
    <Svg>
      <path d="M15 3v11.5a4 4 0 1 1-4-4" />
      <path d="M15 3c.4 2.6 2 4.2 5 4.4" />
    </Svg>
  ),
  x: (
    <Svg>
      <path d="M4 4l16 16M20 4L4 20" />
    </Svg>
  ),
  youtube: (
    <Svg>
      <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
      <path d="M10 9.5l5 2.5-5 2.5z" fill="currentColor" />
    </Svg>
  ),
}

/** Back-to-top: appears after scrolling 600px, smooth-scrolls to top. */
export function BackToTop() {
  const [show, setShow] = useState(false)
  useEffect(() => {
    const on = () => setShow(window.scrollY > 600)
    on()
    window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])
  return (
    <button
      type="button"
      aria-label="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      className={`glass glass-strong fixed bottom-24 right-5 z-40 flex h-12 w-12 items-center justify-center text-mauve transition-all duration-300 hover:-translate-y-1 hover:bg-white ${
        show ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-4 opacity-0'
      }`}
      style={{ borderRadius: 999 }}
      tabIndex={show ? 0 : -1}
    >
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M12 19V5M5 12l7-7 7 7" />
      </svg>
    </button>
  )
}

/**
 * Header: centered logo on top, navigation centered beneath.
 * On < md screens the nav collapses into a hamburger dropdown.
 */
export function Header({ path }: { path: string }) {
  const [open, setOpen] = useState(false)

  // Close menu on route change and on Escape
  useEffect(() => setOpen(false), [path])
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <header className="sticky top-0 z-50 px-3 pt-3">
      <div className="glass glass-strong mx-auto max-w-6xl px-5 py-3" style={{ borderRadius: 28 }}>
        <div className="relative flex items-center justify-center">
          <a href="#/" className="flex flex-col items-center leading-none" aria-label="NULGlow home">
            <span className="text-2xl font-extrabold tracking-tight">
              NUL<span className="accent-serif">Glow</span>
            </span>
            <span className="mt-1 hidden text-[0.68rem] font-medium uppercase tracking-[0.18em] text-ink-soft sm:block">
              Skin pharmacist for local beauty store products
            </span>
          </a>
          <button
            type="button"
            className="absolute right-0 flex h-11 w-11 items-center justify-center rounded-full text-mauve hover:bg-white/70 md:hidden"
            aria-expanded={open}
            aria-controls="primary-nav"
            aria-label={open ? 'Close menu' : 'Open menu'}
            onClick={() => setOpen(!open)}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>

        <nav id="primary-nav" aria-label="Primary" className={`${open ? 'mt-4 block' : 'hidden'} md:mt-3 md:block`}>
          <ul className="flex flex-col items-stretch gap-1 md:flex-row md:items-center md:justify-center md:gap-2">
            {ROUTES.map((r) => {
              const active = r.path === path
              return (
                <li key={r.path}>
                  <a
                    href={`#${r.path}`}
                    aria-current={active ? 'page' : undefined}
                    className={`flex min-h-11 items-center justify-center rounded-full px-5 text-sm font-semibold transition-colors ${
                      active ? 'bg-rose text-plum' : 'text-ink-soft hover:bg-white/80 hover:text-mauve'
                    }`}
                  >
                    {r.label}
                  </a>
                </li>
              )
            })}
          </ul>
        </nav>
      </div>
    </header>
  )
}

/** Newsletter form with inline validation + success state. */
function Newsletter() {
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState<'idle' | 'error' | 'done'>('idle')
  const [busy, setBusy] = useState(false)
  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const trap = honeypot(e)
    if (busy) return
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setStatus('error')
    setBusy(true)
    try {
      await api.subscribe(email, trap)
      setStatus('done')
    } catch {
      setStatus('error')
    } finally {
      setBusy(false)
    }
  }
  return (
    <form onSubmit={submit} noValidate aria-labelledby="nl-title" className="relative">
      <Honeypot />
      <h3 id="nl-title" className="text-xl font-bold">
        <a href="https://nul.ls/" target="_blank" rel="noopener noreferrer" className="hover:underline">
          The weekly <span className="accent-serif">drop</span>
          <span className="sr-only"> (NUL updates, opens in a new tab)</span>
        </a>
      </h3>
      <p className="mt-2 text-sm text-ink-soft">One email, every Friday. New student deals and one pharmacist tip.</p>
      {status === 'done' ? (
        <p role="status" className="mt-4 rounded-2xl bg-white/70 p-4 text-sm font-semibold text-mauve">
          You're in. Check your inbox to confirm.
        </p>
      ) : (
        <>
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <label htmlFor="nl-email" className="sr-only">
              Email address
            </label>
            <input
              id="nl-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="nthatisikolosoa@nul.ls"
              autoComplete="email"
              aria-invalid={status === 'error'}
              aria-describedby={status === 'error' ? 'nl-error' : undefined}
              className="min-h-11 flex-1 rounded-full border border-white bg-white/70 px-5 text-sm placeholder:text-ink-soft/70"
            />
            <button type="submit" disabled={busy} className="btn btn-primary">
              {busy ? 'Subscribing…' : 'Subscribe'}
            </button>
          </div>
          {status === 'error' && (
            <p id="nl-error" role="alert" className="mt-2 text-sm font-semibold text-mauve">
              Enter a valid email address, or try again in a moment.
            </p>
          )}
        </>
      )}
    </form>
  )
}

/** Fat footer: newsletter, link columns, map, socials. */
export function Footer() {
  const socials = [
    { label: 'Instagram', icon: Icons.instagram },
    { label: 'TikTok', icon: Icons.tiktok },
    { label: 'X', icon: Icons.x },
    { label: 'YouTube', icon: Icons.youtube },
  ]
  return (
    <footer className="relative mt-24 px-3 pb-3">
      <div className="glass glass-strong mx-auto max-w-6xl p-6 sm:p-10" style={{ borderRadius: 36 }}>
        <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr_1.2fr]">
          <div className="space-y-8">
            <Newsletter />
            <div>
              <p className="text-sm font-bold uppercase tracking-widest text-mauve">Follow</p>
              <ul className="mt-3 flex gap-3">
                {socials.map((s) => (
                  <li key={s.label}>
                    <a
                      href="#/"
                      aria-label={`NULGlow on ${s.label}`}
                      className="flex h-11 w-11 items-center justify-center rounded-full bg-white/70 text-mauve transition hover:-translate-y-1 hover:bg-rose hover:text-plum"
                    >
                      {s.icon}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <nav aria-label="Footer pages">
              <p className="text-sm font-bold uppercase tracking-widest text-mauve">Explore</p>
              <ul className="mt-3 space-y-1 text-sm">
                {ROUTES.map((r) => (
                  <li key={r.path}>
                    <a href={`#${r.path}`} className="inline-flex min-h-8 items-center text-ink-soft hover:text-mauve hover:underline">
                      {r.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
            <div>
              <p className="text-sm font-bold uppercase tracking-widest text-mauve">Visit</p>
              <address className="mt-3 text-sm not-italic leading-relaxed text-ink-soft">
                National University of Lesotho
                <br />
                Main Campus, Roma 180
                <br />
                Mon–Fri, 14:00–17:00
                <br />
                <a href="mailto:clara.kolosoan@gmail.com" className="font-semibold text-mauve underline">
                  clara.kolosoan@gmail.com
                </a>
              </address>
            </div>
          </div>

          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-mauve">Find us</p>
            <div className="mt-3 overflow-hidden rounded-2xl border border-white shadow-sm">
              <iframe
                title="Map showing the National University of Lesotho main campus, Roma"
                src="https://www.google.com/maps?q=-29.4517,27.7186&z=15&output=embed"
                className="h-52 w-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <p className="mt-2 text-xs text-ink-soft">
              National University of Lesotho, Roma 180 · <span className="whitespace-nowrap">29.4517° S, 27.7186° E</span>
            </p>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-2 border-t border-mauve/20 pt-6 text-xs text-ink-soft sm:flex-row">
          <p>© 2026 NULGlow. Skin pharmacist for local beauty store products.</p>
          <p>Not medical advice. See a doctor for persistent skin concerns.</p>
        </div>
      </div>
    </footer>
  )
}

/** Student sign-up dialog. */
function SignUpDialog({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [skin, setSkin] = useState('')
  const [concern, setConcern] = useState('')
  const [err, setErr] = useState('')
  const [done, setDone] = useState(false)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    document.getElementById('su-name')?.focus()
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])
  const [busy, setBusy] = useState(false)
  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const trap = honeypot(e)
    if (busy) return
    if (!name.trim()) return setErr('Please enter your name.')
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setErr('Enter a valid email address.')
    setErr('')
    setBusy(true)
    try {
      await api.signup({ name, email, skinType: skin, concerns: concern, website: trap })
      setDone(true)
    } catch (e) {
      const fe = e instanceof ApiError ? Object.values(e.fields)[0] : undefined
      setErr(fe ?? (e as Error).message)
    } finally {
      setBusy(false)
    }
  }
  const field = 'mt-1 min-h-11 w-full rounded-2xl border border-white bg-white/80 px-4 text-sm'
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-plum/40 p-3 sm:items-center" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-labelledby="su-title" onClick={(e) => e.stopPropagation()} className="glass glass-strong w-full max-w-md p-6 sm:p-8" style={{ borderRadius: 32 }}>
        <div className="flex items-start justify-between gap-4">
          <h2 id="su-title" className="text-2xl font-extrabold">
            Join <span className="accent-serif">NULGlow</span>
          </h2>
          <button type="button" onClick={onClose} aria-label="Close sign up" className="flex h-10 w-10 items-center justify-center rounded-full text-mauve hover:bg-white/70">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" /></svg>
          </button>
        </div>
        {done ? (
          <div role="status" className="mt-5">
            <p className="rounded-2xl bg-white/70 p-4 font-semibold text-mauve">Welcome, {name.split(' ')[0]}. We'll send student deals and routine tips to {email}.</p>
            <a href="#/recommendations" onClick={onClose} className="btn btn-primary mt-4 w-full">Build my routine</a>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="relative mt-4 space-y-4">
            <Honeypot />
            <p className="text-sm text-ink-soft">Free for NUL students. Get weekly deals and save your routine.</p>
            <label className="block text-sm font-semibold">Name
              <input id="su-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" className={field} />
            </label>
            <label className="block text-sm font-semibold">Email
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" placeholder="nthatisikolosoa@nul.ls" className={field} />
            </label>
            <label className="block text-sm font-semibold">Skin type (optional)
              <select value={skin} onChange={(e) => setSkin(e.target.value)} className={field}>
                <option value="">Not sure yet</option>
                {SKIN_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </label>
            <label className="block text-sm font-semibold">Skin concerns (optional)
              <input value={concern} onChange={(e) => setConcern(e.target.value)} placeholder="Acne, dark spots, eczema, vitiligo…" className={field} />
            </label>
            {err && <p role="alert" className="text-sm font-semibold text-mauve">{err}</p>}
            <button type="submit" disabled={busy} className="btn btn-primary w-full">{busy ? 'Signing up…' : 'Sign up'}</button>
          </form>
        )}
      </div>
    </div>
  )
}

/** Persistent bar on every page: sign up + build routine. */
export function StickyCta({ path }: { path: string }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <div className="fixed inset-x-0 bottom-0 z-40 px-3 pb-3">
        <div className="glass glass-strong mx-auto flex max-w-2xl flex-col items-center justify-between gap-2 px-4 py-3 sm:flex-row sm:px-6" style={{ borderRadius: 28 }}>
          <p className="hidden text-sm font-semibold sm:block">Student? Get a routine in 2 minutes.</p>
          <div className="flex w-full gap-2 sm:w-auto">
            <button type="button" onClick={() => setOpen(true)} className="btn btn-ghost !min-h-11 flex-1 text-sm sm:flex-none">Sign up</button>
            <a href="#/recommendations" aria-current={path === '/recommendations' ? 'page' : undefined} className="btn btn-primary !min-h-11 flex-1 text-sm sm:flex-none">Build my routine</a>
          </div>
        </div>
      </div>
      {open && <SignUpDialog onClose={() => setOpen(false)} />}
    </>
  )
}

import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // GitHub Pages serves a project site from /<repo-name>/, so the deploy workflow sets BASE_PATH=/<repo-name>/.
  // Locally (and on a single server) it stays '/'.
  base: process.env.BASE_PATH || '/',
  server: {
    // In dev, forward /api to the backend so the browser sees one origin (no CORS needed).
    proxy: { '/api': 'http://localhost:3001' },
  },
})

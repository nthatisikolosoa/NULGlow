/**
 * Talks to the NULGlow API. Same-origin by default: the Vite dev server proxies /api, and in production
 * the API server serves this site, so no URL is needed. Set VITE_API_URL only if the API lives elsewhere.
 */
const BASE = (import.meta.env.VITE_API_URL as string | undefined) ?? ''

/** Thrown for any non-2xx response. `fields` maps input name -> message (same wording as the UI's own validation). */
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public fields: Record<string, string> = {},
  ) {
    super(message)
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response
  try {
    res = await fetch(`${BASE}/api${path}`, { ...init, headers: { 'Content-Type': 'application/json', ...init?.headers } })
  } catch {
    throw new ApiError(0, 'Could not reach the server. Check your connection and try again.')
  }
  if (res.status === 204) return undefined as T
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new ApiError(res.status, body.error ?? 'Something went wrong.', body.fields)
  return body as T
}
const post = <T>(path: string, data: unknown) => request<T>(path, { method: 'POST', body: JSON.stringify(data) })
const qs = (o: Record<string, string | number | undefined>) => {
  const p = new URLSearchParams()
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== '') p.set(k, String(v))
  const s = p.toString()
  return s ? `?${s}` : ''
}

export interface Review { id: number; name: string; course: string; quote: string; rating: number; createdAt: string }

export const api = {
  // --- content ---
  products: (f: { step?: string; brand?: string; q?: string; sort?: string } = {}) => request<{ total: number; products: unknown[] }>(`/products${qs(f)}`),
  brands: () => request<{ brands: unknown[] }>('/brands'),
  routine: (skin: string, budget: string, concerns: string[] = []) => request<{ steps: unknown[]; total: number; concerns: unknown[] }>(`/routines${qs({ skin, budget, concerns: concerns.join(',') })}`),
  deals: () => request<{ deals: unknown[] }>('/deals'),
  plans: () => request<{ plans: unknown[] }>('/plans'),
  stats: () => request<{ stats: { value: string; label: string }[] }>('/stats'),

  // --- reviews ---
  reviews: () => request<{ count: number; average: number | null; reviews: Review[] }>('/reviews'),
  createReview: (r: { name: string; course?: string; quote: string; rating: number }) => post<{ ok: true; published: boolean; review: Review }>('/reviews', r),

  // --- forms ---
  contact: (d: { name: string; email: string; topic: string; message: string }) => post<{ ok: true; message: string }>('/contact', d),
  subscribe: (email: string) => post<{ ok: true; message: string }>('/newsletter/subscribe', { email }),
  signup: (d: { name: string; email: string; skinType?: string; concerns?: string }) => post<{ ok: true; message: string }>('/signup', d),
}

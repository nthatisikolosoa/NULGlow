import { createElement, useEffect, useRef, useState, type ReactNode } from 'react'

/**
 * Reveal: fades + lifts children in once they enter the viewport.
 * Uses IntersectionObserver; `delay` staggers siblings.
 */
export function Reveal({
  children,
  delay = 0,
  className = '',
  as: Tag = 'div',
}: {
  children: ReactNode
  delay?: number
  className?: string
  as?: 'div' | 'section' | 'li' | 'article'
}) {
  const ref = useRef<HTMLElement>(null)
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVisible(true)
          io.disconnect()
        }
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])
  return createElement(
    Tag,
    {
      ref,
      className: `reveal ${visible ? 'is-visible' : ''} ${className}`,
      style: { '--delay': `${delay}ms` } as React.CSSProperties,
    },
    children,
  )
}

/** Section heading with eyebrow label and serif accent word. */
export function SectionHead({
  eyebrow,
  title,
  accent,
  intro,
  id,
}: {
  eyebrow: string
  title: string
  accent: string
  intro?: string
  id?: string
}) {
  return (
    <Reveal className="mx-auto mb-12 max-w-2xl text-center">
      <p className="mb-3 text-xs font-semibold uppercase tracking-[0.22em] text-mauve">{eyebrow}</p>
      <h2 id={id} className="text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
        {title} <span className="accent-serif">{accent}</span>
      </h2>
      {intro && <p className="mt-4 text-lg text-ink-soft">{intro}</p>}
    </Reveal>
  )
}

/** Shared page wrapper: ambient blobs + padded content column. */
export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative overflow-hidden">
      <div className="blob -left-24 top-40 h-96 w-96 bg-rose" aria-hidden="true" />
      <div className="blob right-0 top-[60rem] h-[28rem] w-[28rem] bg-[#d9b3d9]" aria-hidden="true" />
      <div className="blob -left-20 top-[120rem] h-96 w-96 bg-rose" aria-hidden="true" />
      <div className="relative">{children}</div>
    </div>
  )
}

/** Compact page title banner for inner pages. */
export function PageTitle({ eyebrow, title, accent, intro }: { eyebrow: string; title: string; accent: string; intro: string }) {
  return (
    <header className="mx-auto max-w-5xl px-5 pb-12 pt-16 text-center sm:pt-24">
      <p className="mb-4 text-xs font-semibold uppercase tracking-[0.22em] text-mauve">{eyebrow}</p>
      <h1 className="text-4xl font-extrabold leading-[1.05] sm:text-6xl">
        {title} <span className="accent-serif">{accent}</span>
      </h1>
      <p className="mx-auto mt-6 max-w-xl text-lg text-ink-soft">{intro}</p>
    </header>
  )
}

export const Container = ({ children, className = '' }: { children: ReactNode; className?: string }) => (
  <div className={`mx-auto w-full max-w-6xl px-5 ${className}`}>{children}</div>
)
